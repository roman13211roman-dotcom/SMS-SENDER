/**
 * subscriber.js — автоматично вступає (підписується) у Facebook-групи зі
 * списку, використовуючи збережену сесію акаунта.
 *
 * Для кожної групи:
 *  1. відкриває сторінку групи;
 *  2. визначає стан: уже учасник / запит уже надіслано / можна вступити;
 *  3. натискає «Приєднатися до групи» і перевіряє результат: вступ
 *     відбувся, або запит чекає схвалення адміністратора;
 *  4. якщо Facebook просить відповісти на запитання чи прийняти правила —
 *     групу пропускає (відповіді та згода на правила лишаються за
 *     користувачем) і закриває вікно.
 *
 * Між групами — випадкова затримка (мін–макс), підтримуються старт за
 * часом, пауза, зупинка та добовий ліміт підписок (захист акаунта від
 * обмежень Facebook).
 *
 * Назви кнопок Facebook залежать від мови інтерфейсу, тому розпізнаються
 * кількома мовами (PL / EN / UK / RU).
 */
import { access } from 'node:fs/promises';
import { t } from './i18n.js';
import { launchChrome } from './chromeLauncher.js';
import {
  sleep,
  randomDelayMs,
  formatClock,
  waitUntilStart,
  waitWhilePaused,
  waitWithStop,
} from './timing.js';

const DEFAULT_MIN_DELAY_SEC = 30;
const DEFAULT_MAX_DELAY_SEC = 90;

// Лише повні назви кнопки вступу до ГРУПИ. Короткі «Join»/«Dołącz» навмисно
// не використовуються: на сторінці групи в бічній колонці є кнопки вступу в
// інші, рекомендовані групи — їх натискати не можна.
const JOIN_NAME = /^(dołącz do grupy|join group|join this group|приєднатися до групи|вступить в группу|вступить в эту группу)$/i;
const MEMBER_NAME = /^(dołączono|joined|ви в групі|вы в группе|joined group)$/i;
const PENDING_NAME = /(anuluj prośbę|anuluj prosbę|cancel request|скасувати запит|отменить запрос|prośba wysłana|request sent|запит надіслано|запрос отправлен)/i;

/**
 * Перша видима кнопка з відповідною назвою (у порядку на сторінці — тобто
 * шапка групи йде раніше за бічну колонку).
 */
async function findVisibleButton(page, nameRe) {
  const candidates = [
    page.getByRole('button', { name: nameRe }),
    page.locator('[role="button"]').filter({ hasText: nameRe }),
  ];
  for (const locator of candidates) {
    const count = await locator.count();
    for (let index = 0; index < Math.min(count, 8); index++) {
      const item = locator.nth(index);
      if (await item.isVisible().catch(() => false)) return item;
    }
  }
  return null;
}

/**
 * @returns {Promise<'member'|'pending'|'canJoin'|'unknown'>}
 */
async function detectGroupState(page) {
  if (await findVisibleButton(page, PENDING_NAME)) return 'pending';
  if (await findVisibleButton(page, MEMBER_NAME)) return 'member';
  if (await findVisibleButton(page, JOIN_NAME)) return 'canJoin';
  return 'unknown';
}

/** Чи відкрилось діалогове вікно (запитання до вступників / правила групи). */
async function isDialogOpen(page) {
  const dialogs = page.getByRole('dialog');
  const count = await dialogs.count();
  for (let index = 0; index < count; index++) {
    if (await dialogs.nth(index).isVisible().catch(() => false)) return true;
  }
  return false;
}

async function closeDialog(page) {
  await page.keyboard.press('Escape').catch(() => {});
  await page.waitForTimeout(600);
  if (await isDialogOpen(page)) {
    const closeButton = page
      .getByRole('dialog')
      .last()
      .getByRole('button', { name: /^(zamknij|close|закрити|закрыть|anuluj|cancel|скасувати|отмена)$/i })
      .first();
    await closeButton.click({ timeout: 2000 }).catch(() => {});
  }
}

function looksLikeLoginPage(url) {
  return /\/login|checkpoint|\/two_step_verification|recover/i.test(url);
}

/**
 * @param {Object} params
 * @param {string[]} params.groups - посилання на групи
 * @param {string} params.cookiesPath - шлях до збереженої сесії акаунта
 * @param {string} [params.lang]
 * @param {number|null} [params.startAt] - timestamp старту (мс) або null
 * @param {number} [params.delayMinSec]
 * @param {number} [params.delayMaxSec]
 * @param {number} [params.dailyLimit] - макс. підписок за добу (0 — без ліміту)
 * @param {() => Promise<number>|number} [params.getTodayCount] - скільки підписок уже зроблено сьогодні
 * @param {(kind: 'joined'|'requested') => void|Promise<void>} [params.onSuccess]
 * @param {(msg: string) => void} [params.onLog]
 * @param {(done: number, total: number) => void} [params.onProgress]
 * @param {(state: string, extra?: object) => void} [params.onStatus]
 * @param {() => boolean} [params.shouldStop]
 * @param {() => boolean} [params.shouldPause]
 * @returns {Promise<{joined:number, requested:number, already:number, skipped:number, failed:number}>}
 */
export async function subscribeToGroups({
  groups,
  cookiesPath,
  lang = 'uk',
  startAt = null,
  delayMinSec = DEFAULT_MIN_DELAY_SEC,
  delayMaxSec = DEFAULT_MAX_DELAY_SEC,
  dailyLimit = 0,
  getTodayCount = () => 0,
  onSuccess = () => {},
  onLog = () => {},
  onProgress = () => {},
  onStatus = () => {},
  shouldStop = () => false,
  shouldPause = () => false,
}) {
  const summary = { joined: 0, requested: 0, already: 0, skipped: 0, failed: 0 };

  try {
    await access(cookiesPath);
  } catch {
    onLog(t(lang, 'publish.needLogin'));
    return summary;
  }

  if (startAt && startAt > Date.now()) {
    onStatus('waiting', { startAt });
    onLog(t(lang, 'subscribe.waitingStart', { time: formatClock(startAt) }));
    const reached = await waitUntilStart(startAt, shouldStop);
    if (!reached) {
      onLog(t(lang, 'publish.stoppedByUser'));
      return summary;
    }
  }
  onStatus('running');

  const browser = await launchChrome();
  try {
    const context = await browser.newContext({
      storageState: cookiesPath,
      viewport: { width: 1366, height: 768 },
    });
    await context.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    });

    for (let i = 0; i < groups.length; i++) {
      if (shouldStop()) {
        onLog(t(lang, 'publish.stoppedByUser'));
        break;
      }
      await waitWhilePaused(shouldPause, shouldStop);
      if (shouldStop()) {
        onLog(t(lang, 'publish.stoppedByUser'));
        break;
      }

      if (dailyLimit > 0) {
        const doneToday = await getTodayCount();
        if (doneToday >= dailyLimit) {
          onLog(t(lang, 'subscribe.limitReached', { limit: dailyLimit }));
          break;
        }
      }

      const url = groups[i];
      const current = i + 1;
      const page = await context.newPage();
      let sessionExpired = false;
      let madeAction = false; // чи робили дію у Facebook (для затримки)

      try {
        onLog(t(lang, 'subscribe.navigating', { current, total: groups.length, url }));
        await page.goto(url, { waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(3500);

        if (looksLikeLoginPage(page.url())) {
          sessionExpired = true;
        } else {
          const before = await detectGroupState(page);

          if (before === 'member') {
            summary.already++;
            onLog(t(lang, 'subscribe.alreadyMember', { current }));
          } else if (before === 'pending') {
            summary.already++;
            onLog(t(lang, 'subscribe.alreadyPending', { current }));
          } else if (before === 'unknown') {
            summary.failed++;
            onLog(t(lang, 'subscribe.noButton', { current }));
          } else {
            const joinButton = await findVisibleButton(page, JOIN_NAME);
            await joinButton.scrollIntoViewIfNeeded().catch(() => {});
            await joinButton.click();
            madeAction = true;
            await page.waitForTimeout(3500);

            if (await isDialogOpen(page)) {
              summary.skipped++;
              onLog(t(lang, 'subscribe.needsAnswers', { current }));
              await closeDialog(page);
            } else {
              const after = await detectGroupState(page);
              if (after === 'member') {
                summary.joined++;
                onLog(t(lang, 'subscribe.joined', { current }));
                await onSuccess('joined');
              } else if (after === 'pending') {
                summary.requested++;
                onLog(t(lang, 'subscribe.requested', { current }));
                await onSuccess('requested');
              } else if (after === 'canJoin') {
                summary.failed++;
                onLog(t(lang, 'subscribe.noEffect', { current }));
              } else {
                summary.failed++;
                onLog(t(lang, 'subscribe.unknownResult', { current }));
              }
            }
          }
        }
      } catch (err) {
        summary.failed++;
        onLog(t(lang, 'subscribe.groupError', { url, message: err.message }));
      }

      await page.close().catch(() => {});
      onProgress(current, groups.length);

      if (sessionExpired) {
        onLog(t(lang, 'subscribe.sessionExpired'));
        break;
      }

      // Затримка потрібна лише після реальної дії; пропущені групи
      // (вже учасник тощо) не навантажують акаунт, тож чекати не треба.
      if (current < groups.length && !shouldStop()) {
        if (madeAction) {
          const waitMs = randomDelayMs(delayMinSec, delayMaxSec);
          onLog(t(lang, 'publish.waiting', { seconds: Math.round(waitMs / 1000) }));
          await waitWithStop(waitMs, shouldPause, shouldStop);
        } else {
          await sleep(1500);
        }
      }
    }

    onLog(
      t(lang, 'subscribe.summary', {
        joined: summary.joined,
        requested: summary.requested,
        already: summary.already,
        skipped: summary.skipped,
        failed: summary.failed,
      }),
    );
    onLog(t(lang, 'subscribe.done'));
  } finally {
    await browser.close().catch(() => {});
  }
  return summary;
}
