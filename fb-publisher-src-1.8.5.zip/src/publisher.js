/**
 * publisher.js — публікує пост у списку Facebook-груп.
 *
 * Логіка ідентична оригінальному Publikuj.js — змінено лише:
 *  - require → import (ES Modules)
 *  - хардкод TEKST_POSTA / GRUPY → параметри функції publishToGroups()
 *  - storageState: 'sesja.json' → параметризований cookiesPath
 *  - console.log → callback onLog (журнал у GUI, з перекладом через i18n)
 *  - додано callback onProgress (для індикатора прогресу)
 *  - додано підтримку зупинки через shouldStop() (кнопка "Зупинити")
 *  - додано підтримку паузи через shouldPause() (кнопка "Пауза")
 *  - додано опційне прикріплення зображення (imagePath) перед публікацією:
 *    зображення записується в системний буфер обміну через
 *    prepareImageClipboard() (надається з main.js, бо лише там є доступ
 *    до Electron clipboard/nativeImage), а потім у полі тексту
 *    виконується справжнє натискання Ctrl+V — так само, як робить
 *    людина руками.
 *  - launchChrome() (chromeLauncher.js) замість прямого chromium.launch():
 *    деякі версії Chrome на Windows одразу закриваються через прапорець
 *    --no-startup-window, тому є повторна спроба без нього.
 *  - clickPublishButton() чекає, поки кнопка "Opublikuj" стане не просто
 *    видимою, а АКТИВНОЮ (до 60 сек) — поки триває завантаження фото,
 *    вона залишається заблокованою.
 *
 * Сам алгоритм проходу по групах, кліки, введення тексту, затримки —
 * не змінені.
 */
import { access } from 'node:fs/promises';
import { t } from './i18n.js';
import { todayKey } from './warmup.js';
import { launchChrome } from './chromeLauncher.js';
import { assertNotBlocked, BlockedError, detectBlock } from './blockDetect.js';
import {
  waitForGroupState,
  joinGroupFlow,
  looksLikeLoginPage,
  dismissWelcomeDialog,
} from './groupJoin.js';
import { splitVariants, createPicker } from './textVariants.js';
import {
  randomDelayMs,
  formatClock,
  waitUntilStart,
  waitWhilePaused,
  waitWithStop,
} from './timing.js';

const DEFAULT_MIN_DELAY_SEC = 3;
const DEFAULT_MAX_DELAY_SEC = 5;

/**
 * Czeka, aż Facebook zakończy przesyłanie zdjęcia i odblokuje przycisk
 * publikacji. Przycisk może znajdować się w dialogu albo na poziomie strony,
 * a jego nazwa zależy od języka interfejsu.
 */
async function clickPublishButton(page, scope, timeoutMs = 60000) {
  const exactName = /^(opublikuj|opublikuj post|post|publish|publish post|опублікувати|опублікувати допис|опубликовать)$/i;
  const candidates = [
    scope.getByRole('button', { name: exactName }),
    scope.locator('[role="button"][aria-label*="Opublikuj" i], button[aria-label*="Opublikuj" i]'),
    page.getByRole('button', { name: exactName }),
  ];

  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    for (const candidate of candidates) {
      const count = await candidate.count();
      for (let index = 0; index < count; index++) {
        const button = candidate.nth(index);
        if (await button.isVisible() && await button.isEnabled()) {
          await button.click();
          return;
        }
      }
    }
    await page.waitForTimeout(500);
  }

  throw new Error('Przycisk publikacji nie został odblokowany w ciągu 60 sekund.');
}

/**
 * Чи є на сторінці групи повідомлення, що ВАШ попередній пост ще чекає
 * схвалення адміністратора («Your pending posts», «Twoje posty oczekujące»,
 * «Ваші дописи на розгляді» тощо). Шукаємо лише в верхній частині сторінки
 * й лише фрази про власні пости — пункт «Pending posts» в меню адміністратора
 * не вважається.
 */
const PENDING_POST_NOTICE =
  /(your pending posts?|your post is pending|your posts? (is|are) (pending|awaiting)|you have \d+ pending posts?|twoje posty oczekuj|twój post oczekuje|twoje posty czekaj|masz \d+ (oczekując|post\w* oczekując)|ваші (дописи|публікації|пости) на розгляді|ваша (публікація|дописи?) (очікує|на розгляді)|у вас є \d+ (публікац|допис)\w* на розгляді|ваши (публикации|посты) на рассмотрении|ваша публикация (ожидает|на рассмотрении))/i;

async function hasPendingPostNotice(page) {
  const matches = page.getByText(PENDING_POST_NOTICE);
  const count = Math.min(await matches.count().catch(() => 0), 6);
  for (let index = 0; index < count; index++) {
    const item = matches.nth(index);
    if (!(await item.isVisible().catch(() => false))) continue;
    const box = await item.boundingBox().catch(() => null);
    if (box && box.y < 1100) return true;
  }
  return false;
}

/**
 * Знаходить діалогове вікно створення поста (яке відкрилось після кліку
 * на "Napisz coś/Write something"). Facebook рендерить його як
 * [role="dialog"]. Якщо з якоїсь причини роль не знайдена — повертаємось
 * до пошуку по всій сторінці (як було раніше), щоб не зламати публікацію.
 *
 * @param {import('playwright').Page} page
 * @returns {Promise<import('playwright').Locator>}
 */
async function getComposerScope(page) {
  const dialogs = page.getByRole('dialog');
  const count = await dialogs.count();
  return count > 0 ? dialogs.last() : page;
}

/**
 * Перевіряє (не блокуючи виконання), чи з'явилось прев'ю завантаженого
 * фото в діалозі. Повертає true/false — сам ніколи не кидає помилку.
 *
 * @param {import('playwright').Locator} scope
 * @param {number} timeout
 */
async function isImagePreviewVisible(scope, timeout = 6000) {
  try {
    const preview = scope.locator('img[referrerpolicy], [aria-label*="Usuń" i], [aria-label*="Remove" i]').first();
    await preview.waitFor({ state: 'visible', timeout });
    return true;
  } catch {
    return false;
  }
}

/**
 * Прикріплює зображення до поста: спершу пробує клік по іконці
 * (надійніший, "довірений" спосіб), і лише якщо він не спрацював (не
 * знайдено кнопку/поле, або прев'ю не підтвердилось) — пробує вставку
 * через буфер обміну як резерв. Ніколи не блокує публікацію намертво:
 * якщо жоден спосіб не підтвердився візуально, попереджає в журналі,
 * але дозволяє публікації продовжитись.
 *
 * @param {import('playwright').Page} page
 * @param {import('playwright').Locator} scope - діалог створення поста
 * @param {import('playwright').Locator} textbox - поле тексту поста
 * @param {string} imagePath
 * @param {(msg: string) => void} onLog
 * @param {string} lang
 */
async function attachImage(page, scope, textbox, imagePath, prepareImageClipboard, withClipboardLock, onLog, lang) {
  onLog(t(lang, 'publish.attachingImage'));

  if (typeof prepareImageClipboard !== 'function') {
    throw new Error(t(lang, 'publish.clipboardUnavailable'));
  }

  // Системний буфер обміну спільний для всіх акаунтів, які працюють
  // паралельно, тому «скопіювати фото → Ctrl+V» виконується під
  // блокуванням: у кожен момент лише один акаунт користується буфером.
  await withClipboardLock(async () => {
    onLog(t(lang, 'publish.copyingImageToClipboard'));
    await prepareImageClipboard(imagePath);

    onLog(t(lang, 'publish.pastingImage'));
    await page.bringToFront();
    await textbox.focus().catch(() => {});
    await page.keyboard.press('Control+V');
    await page.waitForTimeout(1500);
  });

  await page.waitForTimeout(3500);
  const confirmed = await isImagePreviewVisible(scope, 10000);
  if (!confirmed) {
    onLog(t(lang, 'publish.imagePreviewNotConfirmed'));
    return;
  }

  onLog(t(lang, 'publish.imagePreviewFound'));
}

const COMPOSER_TRIGGER = /napisz coś|write something|напишіть щось|напишіть що-небудь|напишите что-нибудь/i;

// Повідомлення, що ТІЛЬКИ ЩО надісланий пост чекає схвалення адміна групи
const PENDING_AFTER_POST =
  /(your post (is|was|has been) (pending|submitted|sent)|pending (admin |administrator )?approval|awaiting (admin |administrator )?approval|post (is )?pending|oczekuje na zatwierdzenie|czeka na zatwierdzenie|oczekuje na akceptację|zatwierdzenia przez administratora|очікує (на )?(схвалення|розгляду)|на розгляді (в )?адміністратор|надіслано на розгляд|ожидает (одобрения|рассмотрения)|отправлена на рассмотрение)/i;

// Повідомлення про помилку публікації
const POST_ERROR_NOTICE =
  /(couldn.t (post|publish)|something went wrong|try again later|nie udało się opublikować|coś poszło nie tak|spróbuj ponownie później|не вдалося опублікувати|щось пішло не так|не удалось опубликовать)/i;

async function anyVisible(page, regex, maxY = 1200) {
  const matches = page.getByText(regex);
  const count = Math.min(await matches.count().catch(() => 0), 6);
  for (let index = 0; index < count; index++) {
    const item = matches.nth(index);
    if (!(await item.isVisible().catch(() => false))) continue;
    const box = await item.boundingBox().catch(() => null);
    if (box && box.y < maxY) return true;
  }
  return false;
}

/** Базова адреса групи (без вкладок «Дискусія», «Учасники» тощо й без параметрів). */
function groupBaseUrl(url) {
  try {
    const u = new URL(url);
    const match = /^\/groups\/([^/]+)/i.exec(u.pathname);
    return match ? `${u.origin}/groups/${match[1]}` : `${u.origin}${u.pathname.replace(/\/$/, '')}`;
  } catch {
    return String(url).replace(/[?#].*$/, '').replace(/\/$/, '');
  }
}

/** Фрагмент тексту поста для пошуку його на сторінці (перший непорожній рядок). */
function makeSnippet(text) {
  const line = String(text).split('\n').map((l) => l.trim()).find(Boolean) ?? '';
  return line.slice(0, 40).trim();
}

/** Чекає, поки на сторінці з'явиться (видимий) фрагмент тексту. */
async function waitForSnippet(page, snippet, timeoutMs, reloadAtMs = 0) {
  const startedAt = Date.now();
  let reloaded = false;
  while (Date.now() - startedAt < timeoutMs) {
    const matches = page.getByText(snippet, { exact: false });
    const count = Math.min(await matches.count().catch(() => 0), 8);
    for (let index = 0; index < count; index++) {
      if (await matches.nth(index).isVisible().catch(() => false)) return true;
    }
    if (reloadAtMs && !reloaded && Date.now() - startedAt >= reloadAtMs) {
      reloaded = true;
      await page.reload({ waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
    }
    await page.waitForTimeout(800);
  }
  return false;
}

const PENDING_LABEL =
  /(pending|awaiting|oczekuj|czeka na|zatwierdzeni|очікує|на розгляді|на рассмотрении|ожидает|рассмотрени)/i;
const JUST_NOW = /(just now|\b\d+\s?(m|min|mins|minutes?)\b|teraz|przed chwilą|щойно|только что|\d+\s?(хв|хвилин|мин))/i;

/** Скільки дописів (articles) на сторінці містять фрагмент тексту. */
async function countArticlesWith(page, snippet) {
  if (!snippet) return 0;
  return page.locator('[role="article"]').filter({ hasText: snippet }).count().catch(() => 0);
}

/** Зберігає знімок екрана й видимий текст — для розбору, якщо статус визначено хибно. */
async function saveDiagnostic(diagDir, name, page) {
  if (!diagDir) return;
  try {
    const fs = await import('node:fs/promises');
    const path = await import('node:path');
    await fs.mkdir(diagDir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const base = path.join(diagDir, `${stamp}_${name}`);
    await page.screenshot({ path: `${base}.png` }).catch(() => {});
    const text = await page.evaluate(() => document.body.innerText.slice(0, 6000)).catch(() => '');
    await fs.writeFile(`${base}.txt`, `${page.url()}\n\n${text}`);
  } catch { /* діагностика не повинна ламати роботу */ }
}

/**
 * Визначає результат після натискання «Опублікувати»:
 *  1) у списку «Мої пости на розгляді» є наш пост → pending (найнадійніша ознака);
 *  2) повідомлення «чекає схвалення» біля поста/на сторінці → pending;
 *  3) у стрічці групи з'явився новий допис із нашим текстом без мітки
 *     «на розгляді» → published.
 * Якщо нічого однозначного — unknown (не вгадуємо).
 *
 * @returns {Promise<'published'|'pending'|'unknown'>}
 */
async function confirmPostOutcome(page, { groupUrl, postText, onLog, lang, current, baseline = 0, diagDir }) {
  if (await anyVisible(page, PENDING_AFTER_POST)) {
    await saveDiagnostic(diagDir, 'pending-toast', page);
    return 'pending';
  }

  const snippet = makeSnippet(postText);
  if (!snippet) {
    onLog(t(lang, 'publish.cannotVerifyImageOnly', { current }));
    return 'published';
  }

  const base = groupBaseUrl(groupUrl);

  // 1) Спершу список «на розгляді»: якщо пост там — він точно не опублікований.
  onLog(t(lang, 'publish.checkingPending', { current }));
  await page.goto(`${base}/my_pending_content`, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
  if (await waitForSnippet(page, snippet, 12000, 6000)) {
    await saveDiagnostic(diagDir, 'pending-list', page);
    return 'pending';
  }

  // 2) Стрічка групи (вкладка «Обговорення»).
  onLog(t(lang, 'publish.checkingFeed', { current }));
  await page.goto(base, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
  if (await anyVisible(page, PENDING_POST_NOTICE, 1400)) {
    await saveDiagnostic(diagDir, 'pending-banner', page);
    return 'pending';
  }
  if (await waitForSnippet(page, snippet, 16000, 8000)) {
    const articles = page.locator('[role="article"]').filter({ hasText: snippet });
    const count = await articles.count().catch(() => 0);
    const first = count ? await articles.first().innerText().catch(() => '') : '';
    if (PENDING_LABEL.test(first.slice(0, 400)) && !JUST_NOW.test(first.slice(0, 200))) {
      await saveDiagnostic(diagDir, 'pending-in-feed', page);
      return 'pending';
    }
    // Такий текст уже був у стрічці раніше — потрібен новий допис або мітка «щойно».
    if (count > baseline || JUST_NOW.test(first.slice(0, 300)) || baseline === 0) {
      await saveDiagnostic(diagDir, 'published', page);
      return 'published';
    }
  }

  await saveDiagnostic(diagDir, 'unknown', page);
  return 'unknown';
}

/**
 * Чи є вже НАШ пост на розгляді в цій групі: відкриваємо список
 * «Мої пости на розгляді» й дивимось, чи там є хоч один допис.
 * Це надійніше, ніж шукати банер на сторінці групи.
 */
const PENDING_ITEM_BUTTON =
  /^(delete|edit|remove|usuń|edytuj|видалити|редагувати|удалить|редактировать)/i;
const PENDING_EMPTY =
  /(no pending|nothing to show|nie masz|brak (oczekując|postów)|немає (дописів|постів|публікацій)|нет (публикаций|записей))/i;

async function pendingListHasItems(page, ms) {
  const articles = page.locator('[role="article"]');
  const buttons = page.getByRole('button', { name: PENDING_ITEM_BUTTON });
  const deadline = Date.now() + ms;
  let emptySeen = 0;
  while (Date.now() < deadline) {
    const n = Math.min(await articles.count().catch(() => 0), 5);
    for (let i = 0; i < n; i++) {
      if (await articles.nth(i).isVisible().catch(() => false)) return 'yes';
    }
    const b = Math.min(await buttons.count().catch(() => 0), 3);
    for (let i = 0; i < b; i++) {
      if (await buttons.nth(i).isVisible().catch(() => false)) return 'yes';
    }
    if (await anyVisible(page, PENDING_EMPTY, 1400)) {
      if (++emptySeen >= 2) return 'no';
    }
    await page.waitForTimeout(700);
  }
  return 'unknown';
}

/**
 * Чи є вже НАШ пост на розгляді в цій групі (список «Мої пости на розгляді»).
 * Порожню сторінку вважаємо порожньою лише за явним підтвердженням; якщо
 * не вдалося визначити — перезавантажуємо й перевіряємо ще раз, а потім
 * вважаємо, що поста немає (діагностика зберігається у папку diagnostics).
 */
async function hasPendingInList(page, groupUrl, diagDir) {
  const base = groupBaseUrl(groupUrl);
  await page.goto(`${base}/my_pending_content`, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
  await page.waitForTimeout(1500);
  let verdict = await pendingListHasItems(page, 10000);
  if (verdict === 'unknown') {
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
    verdict = await pendingListHasItems(page, 8000);
  }
  if (verdict === 'unknown') await saveDiagnostic(diagDir, 'pending-list-unclear', page);
  await page.goto(base, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
  return verdict === 'yes';
}

/** Чекає, поки вікно створення поста закриється (пост надіслано). */
async function waitForComposerClosed(page, timeoutMs = 25000) {
  const composer = page.getByRole('dialog').filter({ has: page.getByRole('textbox') });
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const open = (await composer.count().catch(() => 0)) > 0 && (await composer.last().isVisible().catch(() => false));
    if (!open) return 'closed';
    await page.waitForTimeout(500);
  }
  return 'open';
}

/**
 * Публікує пост у групі, де акаунт уже є учасником, і перевіряє результат.
 * @returns {Promise<{status:'published'|'pending'|'failed', reason?:string}>}
 */
async function postToGroup({
  page, lang, current, groupUrl, postText, imagePath, prepareImageClipboard, withClipboardLock, onLog, stateWasUnknown, diagDir, getPendingSince, setPendingSince,
}) {
  await dismissWelcomeDialog(page).catch(() => {});
  onLog(t(lang, 'publish.checkingExisting', { current }));
  const pendingKey = groupBaseUrl(groupUrl);
  const today = todayKey();
  // Старий пост на розгляді блокує новий лише в день надсилання; з наступного
  // дня (якщо адмін так і не розглянув) публікуємо новий.
  const shouldSkipForPending = async () => {
    const since = await getPendingSince(pendingKey);
    // Немає запису — пост надіслано раніше (до цієї версії), тож він «старий».
    if (since && since >= today) return true;
    onLog(t(lang, since ? 'publish.pendingOld' : 'publish.pendingOldUnknown', { current, date: since }));
    return false;
  };

  if (await hasPendingInList(page, groupUrl, diagDir)) {
    if (await shouldSkipForPending()) {
      onLog(t(lang, 'publish.pendingSkip', { current }));
      return { status: 'pending', reason: 'already' };
    }
  }

  const trigger = page.getByText(COMPOSER_TRIGGER).first();
  const visible = await trigger
    .waitFor({ state: 'visible', timeout: 30000 })
    .then(() => true)
    .catch(() => false);
  if (!visible) return { status: 'failed', reason: stateWasUnknown ? 'noButton' : 'noComposer' };
  await page.waitForTimeout(1200);
  await dismissWelcomeDialog(page).catch(() => {});
  await assertNotBlocked(page);

  if (await hasPendingPostNotice(page)) {
    if (await shouldSkipForPending()) {
      onLog(t(lang, 'publish.pendingSkip', { current }));
      return { status: 'pending', reason: 'already' };
    }
  }

  const baseline = await countArticlesWith(page, makeSnippet(postText));

  await trigger.click();
  await page.waitForTimeout(1500);

  const composerScope = await getComposerScope(page);
  const textbox = composerScope.getByRole('textbox').first();

  await page.keyboard.type(postText, { delay: 2 });
  await page.waitForTimeout(1000);

  if (imagePath) {
    await attachImage(page, composerScope, textbox, imagePath, prepareImageClipboard, withClipboardLock, onLog, lang);
  }

  await clickPublishButton(page, composerScope);
  onLog(t(lang, 'publish.verifyingPost', { current }));

  const closed = await waitForComposerClosed(page, 25000);
  await page.waitForTimeout(2500);
  await assertNotBlocked(page);

  if (await anyVisible(page, POST_ERROR_NOTICE)) return { status: 'failed', reason: 'publishError' };
  if (closed === 'open') return { status: 'failed', reason: 'notConfirmed' };

  const verdict = await confirmPostOutcome(page, { groupUrl, postText, onLog, lang, current, baseline, diagDir });
  if (verdict === 'pending') {
    await setPendingSince(pendingKey, today);
    return { status: 'pending', reason: 'posted' };
  }
  if (verdict === 'published') return { status: 'published' };
  return { status: 'failed', reason: 'notConfirmed' };
}

/**
 * Для кожної групи: відкриває її, вступає (якщо акаунт ще не учасник),
 * публікує пост і перевіряє результат.
 *
 * Результат по групі (onResult): published | pending (пост чекає схвалення
 * адміна) | joinPending (заявка на вступ чекає схвалення) | failed + reason.
 *
 * @param {Object} params
 * @param {string} params.text - текст публікації (варіанти через --- та {a|b})
 * @param {string[]} params.groups - список URL груп
 * @param {string} params.cookiesPath - шлях до збереженої сесії
 * @param {string} [params.imagePath]
 * @param {string} [params.lang]
 * @param {boolean} [params.autoJoin] - вступати в групу, якщо ще не учасник
 * @param {boolean} [params.autoForm] - автозаповнення анкети вступу
 * @param {string} [params.formAnswer] - відповідь на текстові запитання анкети
 * @param {number} [params.dailyJoinLimit] - макс. вступів за добу (0 — без ліміту)
 * @param {() => Promise<number>|number} [params.getJoinCount] - скільки вступів уже зроблено сьогодні
 * @param {(kind: 'joined'|'requested') => void|Promise<void>} [params.onJoin]
 * @param {(url: string, outcome: {status: string, reason?: string}) => void|Promise<void>} [params.onResult]
 * @param {() => void|Promise<void>} [params.onSuccess] - лише після опублікованого поста
 */
export async function publishToGroups({
  text,
  groups,
  cookiesPath,
  imagePath = null,
  lang = 'uk',
  autoJoin = true,
  autoForm = true,
  formAnswer = '',
  dailyJoinLimit = 0,
  diagDir = '',
  getPendingSince = () => null,
  setPendingSince = () => {},
  getJoinCount = () => 0,
  onJoin = () => {},
  onResult = () => {},
  onLog = () => {},
  onProgress = () => {},
  shouldStop = () => false,
  shouldPause = () => false,
  prepareImageClipboard = null,
  onSuccess = () => {},
  startAt = null,
  delayMinSec = DEFAULT_MIN_DELAY_SEC,
  delayMaxSec = DEFAULT_MAX_DELAY_SEC,
  onStatus = () => {},
  withClipboardLock = (fn) => fn(),
  onBlocked = () => {},
}) {
  try {
    await access(cookiesPath);
  } catch {
    onLog(t(lang, 'publish.needLogin'));
    return;
  }

  if (imagePath) {
    try {
      await access(imagePath);
      onLog(t(lang, 'publish.imageWillBeUsed', { path: imagePath }));
    } catch {
      onLog(t(lang, 'publish.imageNotFound', { path: imagePath }));
      return;
    }
  }

  if (startAt && startAt > Date.now()) {
    onStatus('waiting', { startAt });
    onLog(t(lang, 'publish.waitingStart', { time: formatClock(startAt) }));
    const reached = await waitUntilStart(startAt, shouldStop);
    if (!reached) {
      onLog(t(lang, 'publish.stoppedByUser'));
      return;
    }
  }
  onStatus('running');

  const browser = await launchChrome();

  try {
    const context = await browser.newContext({
      storageState: cookiesPath,
      viewport: { width: 1366, height: 768 },
    });
    await context.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    });

    const variants = splitVariants(text);
    const nextText = createPicker(variants);
    if (variants.length > 1) onLog(t(lang, 'publish.variantsCount', { count: variants.length }));

    const counts = { published: 0, pending: 0, joinPending: 0, failed: 0 };

    for (let i = 0; i < groups.length; i++) {
      if (shouldStop()) {
        onLog(t(lang, 'publish.stoppedByUser'));
        break;
      }
      await waitWhilePaused(shouldPause, shouldStop);
      if (shouldStop()) {
        onLog(t(lang, 'publish.stoppedByUser'));
        break;
      }

      const url = groups[i];
      const current = i + 1;
      const page = await context.newPage();
      let outcome = { status: 'failed', reason: 'publishError' };
      let acted = false; // чи робили реальні дії (вступ/публікація) — тоді потрібна затримка
      let blocked = false;
      let sessionExpired = false;
      const tick = (sec) => onLog(t(lang, 'subscribe.stillLoading', { current, seconds: sec }));

      try {
        await onResult(url, { status: 'working' });
        onLog(t(lang, 'publish.navigating', { current, total: groups.length, url }));
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => onLog(t(lang, 'subscribe.slowPage', { current })));
        onLog(t(lang, 'subscribe.loading', { current }));

        let state = await waitForGroupState(page, 45000, tick);
        if (state === 'unknown' && !looksLikeLoginPage(page.url())) {
          // Це може бути група, де ви власник/адмін і кнопок вступу немає — перевіримо поле публікації
          const hasComposer = await page.getByText(COMPOSER_TRIGGER).first().isVisible().catch(() => false);
          if (!hasComposer) {
            onLog(t(lang, 'subscribe.reloading', { current }));
            await page.reload({ waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
            state = await waitForGroupState(page, 45000, tick);
          }
        }
        await assertNotBlocked(page);

        if (looksLikeLoginPage(page.url())) {
          sessionExpired = true;
          outcome = { status: 'failed', reason: 'session' };
        } else if (state === 'pending') {
          onLog(t(lang, 'subscribe.alreadyPending', { current }));
          outcome = { status: 'joinPending', reason: 'already' };
        } else {
          let canPost = true;
          if (state === 'member') {
            onLog(t(lang, 'publish.alreadyMember', { current }));
          } else if (state === 'canJoin') {
            if (!autoJoin) {
              outcome = { status: 'failed', reason: 'autoJoinOff' };
              canPost = false;
            } else if (dailyJoinLimit > 0 && (await getJoinCount()) >= dailyJoinLimit) {
              onLog(t(lang, 'subscribe.limitReached', { limit: dailyJoinLimit }));
              outcome = { status: 'failed', reason: 'joinLimit' };
              canPost = false;
            } else {
              onLog(t(lang, 'publish.joining', { current }));
              const joined = await joinGroupFlow(page, { autoForm, formAnswer, onLog, lang, current });
              acted = true;
              if (joined.result === 'pending') {
                await onJoin('requested');
                onLog(t(lang, 'subscribe.requested', { current }));
                outcome = { status: 'joinPending', reason: 'sent' };
                canPost = false;
              } else if (joined.result === 'failed') {
                outcome = { status: 'failed', reason: joined.reason };
                canPost = false;
              } else {
                await onJoin('joined');
                onLog(t(lang, 'subscribe.joined', { current }));
                await page.waitForTimeout(2000 + Math.random() * 2000);
              }
            }
          }
          if (canPost) {
            outcome = await postToGroup({
              page,
              lang,
              current,
              groupUrl: url,
              postText: nextText(),
              imagePath,
              prepareImageClipboard,
              withClipboardLock,
              onLog,
              stateWasUnknown: state === 'unknown',
              diagDir,
              getPendingSince,
              setPendingSince,
            });
            if (outcome.status === 'published' || outcome.reason === 'posted') acted = true;
            if (outcome.status === 'published') await onSuccess();
          }
        }
      } catch (err) {
        const reason = err instanceof BlockedError ? err.reason : await detectBlock(page);
        if (reason) {
          blocked = true;
          outcome = { status: 'failed', reason: 'blocked' };
          onBlocked(reason);
        } else {
          outcome = { status: 'failed', reason: 'publishError' };
          onLog(t(lang, 'publish.groupError', { url, message: err.message }));
        }
      }

      counts[outcome.status] = (counts[outcome.status] ?? 0) + 1;
      onLog(
        outcome.status === 'failed'
          ? t(lang, 'publish.resultFailed', { current, reason: t(lang, `reason.${outcome.reason}`) })
          : t(lang, `publish.result.${outcome.status}.${outcome.reason ?? 'ok'}`, { current }),
      );
      await onResult(url, outcome);

      await page.close().catch(() => {});
      onProgress(current, groups.length);
      if (blocked) break;
      if (sessionExpired) {
        onLog(t(lang, 'subscribe.sessionExpired'));
        break;
      }

      if (i < groups.length - 1 && !shouldStop() && acted) {
        const wait = randomDelayMs(delayMinSec, delayMaxSec);
        onLog(t(lang, 'publish.waiting', { seconds: Math.round(wait / 1000) }));
        await waitWithStop(wait, shouldPause, shouldStop);
      }
    }

    onLog(t(lang, 'publish.summary', counts));
    onLog(t(lang, 'publish.done'));
  } finally {
    await browser.close().catch(() => {});
  }
}
