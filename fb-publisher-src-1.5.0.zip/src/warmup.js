/**
 * warmup.js — прогрів нового акаунта: навантаження автоматично росте
 * за днями від старту прогріву.
 *
 * День 1–2:   лише перегляд і до 2 лайків
 * День 3–5:   лайки
 * День 6–8:   + підписки на людей
 * День 9–11:  + коментарі й підписка на групи (до 5 на добу)
 * День 12–14: + публікації (до 3 на добу), підписка на групи до 10
 * День 15+:   прогрів завершено — обмежень немає
 */

export const WARMUP_DAYS = 14;

const STAGES = [
  { from: 1, to: 2, likes: [0, 2], follows: [0, 0], comments: [0, 0], actionsPerDay: 6, joinPerDay: 0, publishPerDay: 0 },
  { from: 3, to: 5, likes: [2, 6], follows: [0, 0], comments: [0, 0], actionsPerDay: 15, joinPerDay: 0, publishPerDay: 0 },
  { from: 6, to: 8, likes: [3, 8], follows: [1, 3], comments: [0, 0], actionsPerDay: 25, joinPerDay: 0, publishPerDay: 0 },
  { from: 9, to: 11, likes: [3, 8], follows: [1, 4], comments: [0, 1], actionsPerDay: 40, joinPerDay: 5, publishPerDay: 0 },
  { from: 12, to: 14, likes: [3, 10], follows: [2, 5], comments: [0, 2], actionsPerDay: 60, joinPerDay: 10, publishPerDay: 3 },
];

export const JOIN_FROM_DAY = STAGES.find((s) => s.joinPerDay > 0).from;
export const PUBLISH_FROM_DAY = STAGES.find((s) => s.publishPerDay > 0).from;

function localMidnight(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
}

export function todayKey(now = new Date()) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}

/**
 * @param {string} startDate - "YYYY-MM-DD" (локальна дата старту прогріву)
 * @returns {null | {day:number, done:true} | (object & {day:number, done:false})}
 */
export function getWarmup(startDate, now = new Date()) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(startDate ?? ''));
  if (!match) return null;
  const start = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  const day = Math.floor((localMidnight(now) - localMidnight(start)) / 86_400_000) + 1;
  if (day < 1) return { day: 1, done: false, ...STAGES[0], joinFromDay: JOIN_FROM_DAY, publishFromDay: PUBLISH_FROM_DAY };
  if (day > WARMUP_DAYS) return { day, done: true };
  const stage = STAGES.find((s) => day >= s.from && day <= s.to);
  return { day, done: false, ...stage, joinFromDay: JOIN_FROM_DAY, publishFromDay: PUBLISH_FROM_DAY };
}

/** Обрізає налаштування активності за лімітами поточного дня прогріву. */
export function clampActivity(activity, warm) {
  if (!warm || warm.done) return activity;
  const cap = (min, max, [, limit]) => {
    const newMax = Math.min(max, limit);
    return [Math.min(min, newMax), newMax];
  };
  const [likesMin, likesMax] = cap(activity.likesMin, activity.likesMax, warm.likes);
  const [followsMin, followsMax] = cap(activity.followsMin, activity.followsMax, warm.follows);
  const [commentsMin, commentsMax] = cap(activity.commentsMin, activity.commentsMax, warm.comments);
  const userLimit = activity.dailyLimit > 0 ? activity.dailyLimit : Infinity;
  return {
    ...activity,
    likesMin,
    likesMax,
    followsMin,
    followsMax,
    commentsMin,
    commentsMax,
    dailyLimit: Math.min(userLimit, warm.actionsPerDay),
  };
}
