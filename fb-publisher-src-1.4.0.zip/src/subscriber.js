/**
 * subscriber.js — автоматично вступає (підписується) у Facebook-групи зі
 * списку, використовуючи збережену сесію акаунта.
 *
 * Для кожної групи:
 *  1. відкриває сторінку групи;
 *  2. визначає стан: уже учасник / запит уже надіслано / можна вступити;
 *  3. натискає «Приєднатися до групи» і перевіряє результат: вступ
 *     відбувся, або запит чекає схвалення адміністратора;
 *  4. якщо Facebook просить відповісти на запитання чи прийняти правила —
 *     групу пропускає (відповіді та згода на правила лишаються за
 *     користувачем) і закриває вікно.
 *
 * Між групами — випадкова затримка (мін–макс), підтримуються старт за
 * часом, пауза, зупинка та добовий ліміт підписок (захист акаунта від
 * обмежень Facebook).
 *
 * Назви кнопок Facebook залежать від мови інтерфейсу, тому розпізнаються
 * кількома мовами (PL / EN / UK / RU).
 */
import { access } from 'node:fs/promises';
import { t } from './i18n.js';
import { launchChrome } from './chromeLauncher.js';
import {
  sleep,
  randomDelayMs,
  formatClock,
  waitUntilStart,
  waitWhilePaused,
  waitWithStop,
} from './timing.js';

const DEFAULT_MIN_DELAY_SEC = 30;
const DEFAULT_MAX_DELAY_SEC = 90;

// Лише повні назви кнопки вступу до ГРУПИ. Короткі «Join»/«Dołącz» навмисно
// не використовуються: на сторінці групи в бічній колонці є кнопки вступу в
// інші, рекомендовані групи — їх натискати не можна.
const JOIN_NAME = /^(dołącz do grupy|join group|join this group|приєднатися до групи|вступить в группу|вступить в эту группу)$/i;
const MEMBER_NAME = /^(dołączono|joined|ви в групі|вы в группе|joined group)$/i;
const PENDING_NAME = /(anuluj prośbę|anuluj prosbę|cancel request|скасувати запит|отменить запрос|prośba wysłana|request sent|запит надіслано|запрос отправлен)/i;

/**
 * Перша видима кнопка з відповідною назвою (у порядку на сторінці — тобто
 * шапка групи йде раніше за бічну колонку).
 */
async function findVisibleButton(page, nameRe) {
  const candidates = [
    page.getByRole('button', { name: nameRe }),
    page.locator('[role="button"]').filter({ hasText: nameRe }),
  ];
  for (const locator of candidates) {
    const count = await locator.count();
    for (let index = 0; index < Math.min(count, 8); index++) {
      const item = locator.nth(index);
      if (await item.isVisible().catch(() => false)) return item;
    }
  }
  return null;
}

/**
 * @returns {Promise<'member'|'pending'|'canJoin'|'unknown'>}
 */
async function detectGroupState(page) {
  if (await findVisibleButton(page, PENDING_NAME)) return 'pending';
  if (await findVisibleButton(page, MEMBER_NAME)) return 'member';
  if (await findVisibleButton(page, JOIN_NAME)) return 'canJoin';
  return 'unknown';
}

/** Чи відкрилось діалогове вікно (запитання до вступників / правила групи). */
async function isDialogOpen(page) {
  const dialogs = page.getByRole('dialog');
  const count = await dialogs.count();
  for (let index = 0; index < count; index++) {
    if (await dialogs.nth(index).isVisible().catch(() => false)) return true;
  }
  return false;
}

async function closeDialog(page) {
  await page.keyboard.press('Escape').catch(() => {});
  await page.waitForTimeout(600);
  if (await isDialogOpen(page)) {
    const closeButton = page
      .getByRole('dialog')
      .last()
      .getByRole('button', { name: /^(zamknij|close|закрити|закрыть|anuluj|cancel|скасувати|отмена)$/i })
      .first();
    await closeButton.click({ timeout: 2000 }).catch(() => {});
  }
}


/**
 * Чекає на результат натискання «Приєднатися»: або відкриється анкета
 * (діалог), або стан групи зміниться (запит надіслано / вже в групі).
 * Facebook інколи реагує повільно, тому чекаємо до timeoutMs, а не
 * фіксований час — так вкладку не закриваємо передчасно.
 *
 * @returns {Promise<'dialog'|'pending'|'member'|'timeout'>}
 */
async function waitForJoinOutcome(page, timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await isDialogOpen(page)) return 'dialog';
    const state = await detectGroupState(page);
    if (state === 'pending' || state === 'member') return state;
    await page.waitForTimeout(500);
  }
  return 'timeout';
}

/**
 * Після відправлення анкети чекає, поки Facebook покаже підсумковий стан
 * («Скасувати запит» / «Ви в групі»). Повертає останній визначений стан.
 */
async function waitForFinalState(page, timeoutMs = 12000) {
  const deadline = Date.now() + timeoutMs;
  let state = 'unknown';
  while (Date.now() < deadline) {
    state = await detectGroupState(page);
    if (state === 'pending' || state === 'member') return state;
    await page.waitForTimeout(600);
  }
  return state;
}

const FORM_NEXT_NAME = /^(prześlij|przeslij|wyślij|wyslij|submit|send|надіслати|відправити|отправить|dalej|next|далі|далее|gotowe|done|готово|dołącz|join|приєднатися)$/i;

/**
 * Заповнює анкету вступу автоматично:
 *  - ставить усі галочки (згода з правилами тощо);
 *  - у текстові поля вписує типову відповідь (якщо задана);
 *  - натискає «Надіслати»/«Далі» (форма може мати кілька кроків).
 * Питання з вибором варіанта (радіокнопки, списки) заповнити універсально
 * неможливо — тоді повертає 'unsupported'.
 *
 * @returns {Promise<{result: 'submitted'|'unsupported'|'needsAnswer'|'stuck', checks: number, texts: number}>}
 */
async function fillJoinForm(page, { answer = '' }) {
  let checks = 0;
  let texts = 0;

  for (let step = 0; step < 5; step++) {
    if (!(await isDialogOpen(page))) return { result: 'submitted', checks, texts };
    const dialog = page.getByRole('dialog').last();

    // Вибір варіанта — не підтримується
    const radios = dialog.getByRole('radio');
    const radioCount = await radios.count();
    let hasUnselectedRadio = false;
    for (let index = 0; index < radioCount; index++) {
      const radio = radios.nth(index);
      if (!(await radio.isVisible().catch(() => false))) continue;
      const selected = await radio.isChecked().catch(() => false);
      if (!selected) hasUnselectedRadio = true;
    }
    const selects = await dialog.getByRole('combobox').count();
    const listboxes = await dialog.getByRole('listbox').count();
    if (hasUnselectedRadio || selects > 0 || listboxes > 0) {
      return { result: 'unsupported', checks, texts };
    }

    // Галочки
    const boxes = dialog.getByRole('checkbox');
    const boxCount = await boxes.count();
    for (let index = 0; index < boxCount; index++) {
      const box = boxes.nth(index);
      if (!(await box.isVisible().catch(() => false))) continue;
      if (await box.isChecked().catch(() => false)) continue;
      try {
        await box.check({ timeout: 2500 });
      } catch {
        await box.click({ timeout: 2500 }).catch(() => {});
      }
      checks++;
    }

    // Текстові відповіді
    const fields = dialog.locator('textarea, input[type="text"], [role="textbox"]');
    const fieldCount = await fields.count();
    for (let index = 0; index < fieldCount; index++) {
      const field = fields.nth(index);
      if (!(await field.isVisible().catch(() => false))) continue;
      const current = ((await field.inputValue().catch(() => null)) ?? (await field.innerText().catch(() => ''))).trim();
      if (current) continue;
      if (!answer) return { result: 'needsAnswer', checks, texts };
      await field.fill(answer).catch(async () => {
        await field.click().catch(() => {});
        await page.keyboard.type(answer, { delay: 5 });
      });
      texts++;
    }

    // Кнопка «Надіслати» / «Далі»
    await page.waitForTimeout(500);
    const nextButton = await findVisibleButton(dialog, FORM_NEXT_NAME);
    if (!nextButton || !(await nextButton.isEnabled().catch(() => false))) {
      return { result: 'stuck', checks, texts };
    }
    await nextButton.click().catch(() => {});
    // Чекаємо, поки діалог закриється (форму надіслано) або зміниться крок
    for (let wait = 0; wait < 12; wait++) {
      await page.waitForTimeout(500);
      if (!(await isDialogOpen(page))) break;
    }
    await page.waitForTimeout(800);
  }

  return { result: (await isDialogOpen(page)) ? 'stuck' : 'submitted', checks, texts };
}

function looksLikeLoginPage(url) {
  return /\/login|checkpoint|\/two_step_verification|recover/i.test(url);
}

/**
 * @param {Object} params
 * @param {string[]} params.groups - посилання на групи
 * @param {string} params.cookiesPath - шлях до збереженої сесії акаунта
 * @param {string} [params.lang]
 * @param {number|null} [params.startAt] - timestamp старту (мс) або null
 * @param {number} [params.delayMinSec]
 * @param {number} [params.delayMaxSec]
 * @param {number} [params.dailyLimit] - макс. підписок за добу (0 — без ліміту)
 * @param {() => Promise<number>|number} [params.getTodayCount] - скільки підписок уже зроблено сьогодні
 * @param {boolean} [params.autoForm] - автоматично заповнювати анкету вступу (галочки, відповідь, «Надіслати»)
 * @param {string} [params.formAnswer] - типова відповідь на текстові запитання анкети
 * @param {(kind: 'joined'|'requested') => void|Promise<void>} [params.onSuccess]
 * @param {(msg: string) => void} [params.onLog]
 * @param {(done: number, total: number) => void} [params.onProgress]
 * @param {(state: string, extra?: object) => void} [params.onStatus]
 * @param {() => boolean} [params.shouldStop]
 * @param {() => boolean} [params.shouldPause]
 * @returns {Promise<{joined:number, requested:number, already:number, skipped:number, failed:number}>}
 */
export async function subscribeToGroups({
  groups,
  cookiesPath,
  lang = 'uk',
  startAt = null,
  delayMinSec = DEFAULT_MIN_DELAY_SEC,
  delayMaxSec = DEFAULT_MAX_DELAY_SEC,
  dailyLimit = 0,
  getTodayCount = () => 0,
  autoForm = true,
  formAnswer = '',
  onSuccess = () => {},
  onLog = () => {},
  onProgress = () => {},
  onStatus = () => {},
  shouldStop = () => false,
  shouldPause = () => false,
}) {
  const summary = { joined: 0, requested: 0, already: 0, skipped: 0, failed: 0 };

  try {
    await access(cookiesPath);
  } catch {
    onLog(t(lang, 'publish.needLogin'));
    return summary;
  }

  if (startAt && startAt > Date.now()) {
    onStatus('waiting', { startAt });
    onLog(t(lang, 'subscribe.waitingStart', { time: formatClock(startAt) }));
    const reached = await waitUntilStart(startAt, shouldStop);
    if (!reached) {
      onLog(t(lang, 'publish.stoppedByUser'));
      return summary;
    }
  }
  onStatus('running');

  const browser = await launchChrome();
  try {
    const context = await browser.newContext({
      storageState: cookiesPath,
      viewport: { width: 1366, height: 768 },
    });
    await context.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
    });

    for (let i = 0; i < groups.length; i++) {
      if (shouldStop()) {
        onLog(t(lang, 'publish.stoppedByUser'));
        break;
      }
      await waitWhilePaused(shouldPause, shouldStop);
      if (shouldStop()) {
        onLog(t(lang, 'publish.stoppedByUser'));
        break;
      }

      if (dailyLimit > 0) {
        const doneToday = await getTodayCount();
        if (doneToday >= dailyLimit) {
          onLog(t(lang, 'subscribe.limitReached', { limit: dailyLimit }));
          break;
        }
      }

      const url = groups[i];
      const current = i + 1;
      const page = await context.newPage();
      let sessionExpired = false;
      let madeAction = false; // чи робили дію у Facebook (для затримки)

      try {
        onLog(t(lang, 'subscribe.navigating', { current, total: groups.length, url }));
        await page.goto(url, { waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(3500);

        if (looksLikeLoginPage(page.url())) {
          sessionExpired = true;
        } else {
          const before = await detectGroupState(page);

          if (before === 'member') {
            summary.already++;
            onLog(t(lang, 'subscribe.alreadyMember', { current }));
          } else if (before === 'pending') {
            summary.already++;
            onLog(t(lang, 'subscribe.alreadyPending', { current }));
          } else if (before === 'unknown') {
            summary.failed++;
            onLog(t(lang, 'subscribe.noButton', { current }));
          } else {
            const joinButton = await findVisibleButton(page, JOIN_NAME);
            await joinButton.scrollIntoViewIfNeeded().catch(() => {});
            await joinButton.click();
            madeAction = true;
            await waitForJoinOutcome(page, 15000);

            let formHandled = true;
            if (await isDialogOpen(page)) {
              if (!autoForm) {
                formHandled = false;
                summary.skipped++;
                onLog(t(lang, 'subscribe.needsAnswers', { current }));
                await closeDialog(page);
              } else {
                const form = await fillJoinForm(page, { answer: formAnswer.trim() });
                if (form.result === 'submitted') {
                  onLog(t(lang, 'subscribe.formSubmitted', { current, checks: form.checks, texts: form.texts }));
                } else {
                  formHandled = false;
                  summary.skipped++;
                  const key = {
                    unsupported: 'subscribe.formUnsupported',
                    needsAnswer: 'subscribe.formNeedsAnswer',
                    stuck: 'subscribe.formStuck',
                  }[form.result];
                  onLog(t(lang, key, { current }));
                  await closeDialog(page);
                }
              }
            }
            if (formHandled) {
              const after = await waitForFinalState(page, 12000);
              if (after === 'member') {
                summary.joined++;
                onLog(t(lang, 'subscribe.joined', { current }));
                await onSuccess('joined');
              } else if (after === 'pending') {
                summary.requested++;
                onLog(t(lang, 'subscribe.requested', { current }));
                await onSuccess('requested');
              } else if (after === 'canJoin') {
                summary.failed++;
                onLog(t(lang, 'subscribe.noEffect', { current }));
              } else {
                summary.failed++;
                onLog(t(lang, 'subscribe.unknownResult', { current }));
              }
            }
          }
        }
      } catch (err) {
        summary.failed++;
        onLog(t(lang, 'subscribe.groupError', { url, message: err.message }));
      }

      // Після реальної дії даємо Facebook дозавершити запит у фоні й не
      // закриваємо вкладку одразу — інакше запит може не зафіксуватись.
      if (madeAction) await page.waitForTimeout(3000 + Math.random() * 2000);

      await page.close().catch(() => {});
      onProgress(current, groups.length);

      if (sessionExpired) {
        onLog(t(lang, 'subscribe.sessionExpired'));
        break;
      }

      // Затримка потрібна лише після реальної дії; пропущені групи
      // (вже учасник тощо) не навантажують акаунт, тож чекати не треба.
      if (current < groups.length && !shouldStop()) {
        if (madeAction) {
          const waitMs = randomDelayMs(delayMinSec, delayMaxSec);
          onLog(t(lang, 'publish.waiting', { seconds: Math.round(waitMs / 1000) }));
          await waitWithStop(waitMs, shouldPause, shouldStop);
        } else {
          await sleep(1500);
        }
      }
    }

    onLog(
      t(lang, 'subscribe.summary', {
        joined: summary.joined,
        requested: summary.requested,
        already: summary.already,
        skipped: summary.skipped,
        failed: summary.failed,
      }),
    );
    onLog(t(lang, 'subscribe.done'));
  } finally {
    await browser.close().catch(() => {});
  }
  return summary;
}
