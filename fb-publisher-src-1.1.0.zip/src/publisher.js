/**
 * publisher.js — публікує пост у списку Facebook-груп.
 *
 * Логіка ідентична оригінальному Publikuj.js — змінено лише:
 *  - require → import (ES Modules)
 *  - хардкод TEKST_POSTA / GRUPY → параметри функції publishToGroups()
 *  - storageState: 'sesja.json' → параметризований cookiesPath
 *  - console.log → callback onLog (журнал у GUI, з перекладом через i18n)
 *  - додано callback onProgress (для індикатора прогресу)
 *  - додано підтримку зупинки через shouldStop() (кнопка "Зупинити")
 *  - додано підтримку паузи через shouldPause() (кнопка "Пауза")
 *  - додано опційне прикріплення зображення (imagePath) перед публікацією:
 *    зображення записується в системний буфер обміну через
 *    prepareImageClipboard() (надається з main.js, бо лише там є доступ
 *    до Electron clipboard/nativeImage), а потім у полі тексту
 *    виконується справжнє натискання Ctrl+V — так само, як робить
 *    людина руками.
 *  - launchChrome() (chromeLauncher.js) замість прямого chromium.launch():
 *    деякі версії Chrome на Windows одразу закриваються через прапорець
 *    --no-startup-window, тому є повторна спроба без нього.
 *  - clickPublishButton() чекає, поки кнопка "Opublikuj" стане не просто
 *    видимою, а АКТИВНОЮ (до 60 сек) — поки триває завантаження фото,
 *    вона залишається заблокованою.
 *
 * Сам алгоритм проходу по групах, кліки, введення тексту, затримки —
 * не змінені.
 */
import { access } from 'node:fs/promises';
import { t } from './i18n.js';
import { launchChrome } from './chromeLauncher.js';

const DEFAULT_MIN_DELAY_SEC = 3;
const DEFAULT_MAX_DELAY_SEC = 5;
const PAUSE_POLL_MS = 500;

/**
 * Випадкова затримка між постами в межах [minSec, maxSec] (секунди).
 * Якщо межі однакові — затримка фіксована.
 */
function randomDelayMs(minSec, maxSec) {
  const lo = Math.max(0, Math.min(minSec, maxSec));
  const hi = Math.max(minSec, maxSec);
  return (lo + Math.random() * (hi - lo)) * 1000;
}

function formatClock(timestamp) {
  const d = new Date(timestamp);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

/**
 * Чекає до вказаного моменту (timestamp, мс). Можна перервати кнопкою
 * "Зупинити". Повертає true, якщо дочекались; false — якщо зупинено.
 */
async function waitUntilStart(startAt, shouldStop) {
  while (Date.now() < startAt) {
    if (shouldStop()) return false;
    await sleep(Math.min(1000, Math.max(50, startAt - Date.now())));
  }
  return !shouldStop();
}

function sleep(ms) {
  return new Promise((res) => setTimeout(res, ms));
}

/**
 * Чекає, поки користувач не зніме паузу (опитує shouldPause() кожні
 * PAUSE_POLL_MS). Перевіряє також shouldStop(), щоб можна було вийти
 * з паузи одразу натисканням "Зупинити".
 */
async function waitWhilePaused(shouldPause, shouldStop) {
  while (shouldPause() && !shouldStop()) {
    await sleep(PAUSE_POLL_MS);
  }
}

/**
 * Затримка між постами, яку можна перервати ("Зупинити") і яка
 * враховує паузу.
 */
async function waitWithStop(ms, shouldPause, shouldStop) {
  const end = Date.now() + ms;
  while (Date.now() < end && !shouldStop()) {
    await sleep(Math.min(500, Math.max(50, end - Date.now())));
  }
  await waitWhilePaused(shouldPause, shouldStop);
}

/**
 * Czeka, aż Facebook zakończy przesyłanie zdjęcia i odblokuje przycisk
 * publikacji. Przycisk może znajdować się w dialogu albo na poziomie strony,
 * a jego nazwa zależy od języka interfejsu.
 */
async function clickPublishButton(page, scope, timeoutMs = 60000) {
  const exactName = /^(opublikuj|opublikuj post|post|publish|publish post|опублікувати|опублікувати допис|опубликовать)$/i;
  const candidates = [
    scope.getByRole('button', { name: exactName }),
    scope.locator('[role="button"][aria-label*="Opublikuj" i], button[aria-label*="Opublikuj" i]'),
    page.getByRole('button', { name: exactName }),
  ];

  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    for (const candidate of candidates) {
      const count = await candidate.count();
      for (let index = 0; index < count; index++) {
        const button = candidate.nth(index);
        if (await button.isVisible() && await button.isEnabled()) {
          await button.click();
          return;
        }
      }
    }
    await page.waitForTimeout(500);
  }

  throw new Error('Przycisk publikacji nie został odblokowany w ciągu 60 sekund.');
}

/**
 * Знаходить діалогове вікно створення поста (яке відкрилось після кліку
 * на "Napisz coś/Write something"). Facebook рендерить його як
 * [role="dialog"]. Якщо з якоїсь причини роль не знайдена — повертаємось
 * до пошуку по всій сторінці (як було раніше), щоб не зламати публікацію.
 *
 * @param {import('playwright').Page} page
 * @returns {Promise<import('playwright').Locator>}
 */
async function getComposerScope(page) {
  const dialogs = page.getByRole('dialog');
  const count = await dialogs.count();
  return count > 0 ? dialogs.last() : page;
}

/**
 * Перевіряє (не блокуючи виконання), чи з'явилось прев'ю завантаженого
 * фото в діалозі. Повертає true/false — сам ніколи не кидає помилку.
 *
 * @param {import('playwright').Locator} scope
 * @param {number} timeout
 */
async function isImagePreviewVisible(scope, timeout = 6000) {
  try {
    const preview = scope.locator('img[referrerpolicy], [aria-label*="Usuń" i], [aria-label*="Remove" i]').first();
    await preview.waitFor({ state: 'visible', timeout });
    return true;
  } catch {
    return false;
  }
}

/**
 * Прикріплює зображення до поста: спершу пробує клік по іконці
 * (надійніший, "довірений" спосіб), і лише якщо він не спрацював (не
 * знайдено кнопку/поле, або прев'ю не підтвердилось) — пробує вставку
 * через буфер обміну як резерв. Ніколи не блокує публікацію намертво:
 * якщо жоден спосіб не підтвердився візуально, попереджає в журналі,
 * але дозволяє публікації продовжитись.
 *
 * @param {import('playwright').Page} page
 * @param {import('playwright').Locator} scope - діалог створення поста
 * @param {import('playwright').Locator} textbox - поле тексту поста
 * @param {string} imagePath
 * @param {(msg: string) => void} onLog
 * @param {string} lang
 */
async function attachImage(page, scope, textbox, imagePath, prepareImageClipboard, withClipboardLock, onLog, lang) {
  onLog(t(lang, 'publish.attachingImage'));

  if (typeof prepareImageClipboard !== 'function') {
    throw new Error(t(lang, 'publish.clipboardUnavailable'));
  }

  // Системний буфер обміну спільний для всіх акаунтів, які працюють
  // паралельно, тому «скопіювати фото → Ctrl+V» виконується під
  // блокуванням: у кожен момент лише один акаунт користується буфером.
  await withClipboardLock(async () => {
    onLog(t(lang, 'publish.copyingImageToClipboard'));
    await prepareImageClipboard(imagePath);

    onLog(t(lang, 'publish.pastingImage'));
    await page.bringToFront();
    await textbox.focus().catch(() => {});
    await page.keyboard.press('Control+V');
    await page.waitForTimeout(1500);
  });

  await page.waitForTimeout(3500);
  const confirmed = await isImagePreviewVisible(scope, 10000);
  if (!confirmed) {
    onLog(t(lang, 'publish.imagePreviewNotConfirmed'));
    return;
  }

  onLog(t(lang, 'publish.imagePreviewFound'));
}

/**
 * @param {Object} params
 * @param {string} params.text - текст публікації
 * @param {string[]} params.groups - список URL груп
 * @param {string} params.cookiesPath - шлях до збереженої сесії (data/cookies.json)
 * @param {string} [params.imagePath] - шлях до зображення (опційно)
 * @param {string} [params.lang] - мова журналу ('uk' | 'en')
 * @param {(msg: string) => void} [params.onLog] - callback для журналу
 * @param {(done: number, total: number) => void} [params.onProgress] - callback прогресу
 * @param {() => boolean} [params.shouldStop] - повертає true, якщо треба зупинити цикл
 * @param {() => boolean} [params.shouldPause] - повертає true, якщо цикл на паузі
 * @param {(imagePath: string) => Promise<void>} [params.prepareImageClipboard] - записує фото в системний буфер
 * @param {() => void} [params.onSuccess] - викликається ЛИШЕ після успішної публікації (не при помилках) — для лічильника постів
 * @param {number|null} [params.startAt] - timestamp (мс), до якого треба почекати перед стартом (null — одразу)
 * @param {number} [params.delayMinSec] - мінімальна затримка між постами, сек
 * @param {number} [params.delayMaxSec] - максимальна затримка між постами, сек
 * @param {(state: string, extra?: object) => void} [params.onStatus] - стан: 'waiting' | 'running'
 * @param {(fn: () => Promise<void>) => Promise<void>} [params.withClipboardLock] - послідовний доступ до буфера обміну
 */
export async function publishToGroups({
  text,
  groups,
  cookiesPath,
  imagePath = null,
  lang = 'uk',
  onLog = () => {},
  onProgress = () => {},
  shouldStop = () => false,
  shouldPause = () => false,
  prepareImageClipboard = null,
  onSuccess = () => {},
  startAt = null,
  delayMinSec = DEFAULT_MIN_DELAY_SEC,
  delayMaxSec = DEFAULT_MAX_DELAY_SEC,
  onStatus = () => {},
  withClipboardLock = (fn) => fn(),
}) {
  try {
    await access(cookiesPath);
  } catch {
    onLog(t(lang, 'publish.needLogin'));
    return;
  }

  if (imagePath) {
    try {
      await access(imagePath);
      onLog(t(lang, 'publish.imageWillBeUsed', { path: imagePath }));
    } catch {
      onLog(t(lang, 'publish.imageNotFound', { path: imagePath }));
      return;
    }
  }

  if (startAt && startAt > Date.now()) {
    onStatus('waiting', { startAt });
    onLog(t(lang, 'publish.waitingStart', { time: formatClock(startAt) }));
    const reached = await waitUntilStart(startAt, shouldStop);
    if (!reached) {
      onLog(t(lang, 'publish.stoppedByUser'));
      return;
    }
  }
  onStatus('running');

  const browser = await launchChrome();

  const context = await browser.newContext({
    storageState: cookiesPath,
    viewport: { width: 1366, height: 768 },
  });

  await context.addInitScript(() => {
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
  });

  for (let i = 0; i < groups.length; i++) {
    if (shouldStop()) {
      onLog(t(lang, 'publish.stoppedByUser'));
      break;
    }

    // Пауза перевіряється між групами, щоб не переривати публікацію
    // на півдорозі — так само, як і зупинка.
    await waitWhilePaused(shouldPause, shouldStop);
    if (shouldStop()) {
      onLog(t(lang, 'publish.stoppedByUser'));
      break;
    }

    const url = groups[i];
    const page = await context.newPage();

    try {
      onLog(t(lang, 'publish.navigating', { current: i + 1, total: groups.length, url }));
      await page.goto(url);
      await page.waitForTimeout(3000);

      await page.getByText(/napisz coś|write something/i).first().click();
      await page.waitForTimeout(1500);

      const composerScope = await getComposerScope(page);
      const textbox = composerScope.getByRole('textbox').first();

      await page.keyboard.type(text, { delay: 2 });
      await page.waitForTimeout(1000);

      if (imagePath) {
        await attachImage(
          page,
          composerScope,
          textbox,
          imagePath,
          prepareImageClipboard,
          withClipboardLock,
          onLog,
          lang,
        );
      }

      await clickPublishButton(page, composerScope);
      await page.waitForTimeout(4000);

      onLog(t(lang, 'publish.published', { current: i + 1 }));
      await onSuccess();
    } catch (err) {
      onLog(t(lang, 'publish.groupError', { url, message: err.message }));
    }

    await page.close();
    onProgress(i + 1, groups.length);

    if (i < groups.length - 1 && !shouldStop()) {
      const czekaj = randomDelayMs(delayMinSec, delayMaxSec);
      onLog(t(lang, 'publish.waiting', { seconds: Math.round(czekaj / 1000) }));
      await waitWithStop(czekaj, shouldPause, shouldStop);
    }
  }

  onLog(t(lang, 'publish.done'));
  await browser.close().catch(() => {});
}
