/**
 * i18n.js — переклади повідомлень, які генерує бекенд (main.js, login.js,
 * publisher.js) і які потрапляють у журнал виконання. Мова обирається
 * користувачем у GUI та зберігається в налаштуваннях (config.language).
 *
 * GUI-тексти (лейбли, кнопки, плейсхолдери) перекладаються окремо, у
 * renderer/i18n.js — вони не потребують Node.js і живуть у renderer-процесі.
 */

const MESSAGES = {
  uk: {
    'login.openWindow': 'Увійдіть вручну у вікні браузера, потім натисніть "Я увійшов" у програмі...',
    'login.sessionSaved': 'Сесію збережено!',
    'publish.needLogin': 'Спочатку потрібно увійти (натисніть "Увійти") — сесію ще не збережено.',
    'publish.imageNotFound': 'Файл зображення не знайдено: {path}',
    'publish.navigating': '[{current}/{total}] Переходжу на: {url}',
    'publish.attachingImage': 'Зображення додається, чекаю завантаження...',
    'publish.imageWillBeUsed': 'Буде додано зображення: {path}',
    'publish.copyingImageToClipboard': 'Копіюю зображення до системного буфера обміну...',
    'publish.pastingImage': 'Поле допису активне — натискаю Ctrl+V...',
    'publish.clipboardUnavailable': 'Системний буфер обміну недоступний.',
    'publish.imagePreviewFound': 'Прев\'ю зображення підтверджено.',
    'publish.imagePreviewNotConfirmed': 'Не вдалося візуально підтвердити прев\'ю фото, але продовжую (можливо, воно все ж додалось) — перевірте результат вручну.',
    'publish.published': 'Опубліковано в групі {current}',
    'publish.groupError': 'Помилка в групі {url}: {message}',
    'publish.stoppedByUser': 'Зупинено користувачем.',
    'publish.waiting': 'Чекаю {seconds} сек перед наступною групою...',
    'publish.done': 'Готово: обробку груп завершено.',
    'publish.criticalError': 'Критична помилка: {message}',
    'publish.stopRequested': 'Отримано команду зупинки — завершую після поточної групи...',
    'publish.paused': 'Публікацію призупинено.',
    'publish.resumed': 'Публікацію відновлено.',
    'publish.waitingStart': 'Чекаю до {time} — тоді почну публікацію...',
    'publish.startTimePassed': 'Час старту ({time}) уже минув — починаю одразу.',
    'publish.alreadyRunning': 'Цей акаунт уже працює.',
    'publish.badDelay': 'Некоректна затримка між постами.',
    'chrome.title': 'Google Chrome не знайдено',
    'chrome.message': 'Для роботи програми потрібен встановлений Google Chrome.',
    'chrome.detail': 'Програма використовує ваш звичайний Chrome, щоб Facebook не розпізнавав автоматизацію. Встановіть Chrome і перезапустіть програму.',
    'chrome.btnDownload': 'Відкрити сторінку завантаження',
    'chrome.btnClose': 'Закрити',
  },
  en: {
    'login.openWindow': 'Log in manually in the browser window, then click "I\'m logged in" in the app...',
    'login.sessionSaved': 'Session saved!',
    'publish.needLogin': 'You need to log in first (click "Log in") — no session saved yet.',
    'publish.imageNotFound': 'Image file not found: {path}',
    'publish.navigating': '[{current}/{total}] Navigating to: {url}',
    'publish.attachingImage': 'Attaching image, waiting for upload...',
    'publish.imageWillBeUsed': 'Will attach image: {path}',
    'publish.copyingImageToClipboard': 'Copying image to the system clipboard...',
    'publish.pastingImage': 'Post field focused — pressing Ctrl+V...',
    'publish.clipboardUnavailable': 'System clipboard is unavailable.',
    'publish.imagePreviewFound': 'Image preview confirmed.',
    'publish.imagePreviewNotConfirmed': 'Could not visually confirm the photo preview, but continuing (it may still have attached) — please check the result manually.',
    'publish.published': 'Published in group {current}',
    'publish.groupError': 'Error in group {url}: {message}',
    'publish.stoppedByUser': 'Stopped by user.',
    'publish.waiting': 'Waiting {seconds} sec before next group...',
    'publish.done': 'Done: group processing finished.',
    'publish.criticalError': 'Critical error: {message}',
    'publish.stopRequested': 'Stop command received — finishing after current group...',
    'publish.paused': 'Posting paused.',
    'publish.resumed': 'Posting resumed.',
    'publish.waitingStart': 'Waiting until {time} — then posting will start...',
    'publish.startTimePassed': 'Start time ({time}) has already passed — starting now.',
    'publish.alreadyRunning': 'This account is already running.',
    'publish.badDelay': 'Invalid delay between posts.',
    'chrome.title': 'Google Chrome not found',
    'chrome.message': 'This app requires Google Chrome to be installed.',
    'chrome.detail': 'The app uses your regular Chrome so Facebook does not detect automation. Please install Chrome and restart the app.',
    'chrome.btnDownload': 'Open download page',
    'chrome.btnClose': 'Close',
  },
};

/**
 * Перекладає ключ повідомлення в поточну мову з підстановкою параметрів.
 * @param {string} lang - 'uk' | 'en'
 * @param {string} key - ключ повідомлення (наприклад, 'publish.published')
 * @param {Object} [params] - значення для підстановки в {фігурні дужки}
 * @returns {string}
 */
export function t(lang, key, params = {}) {
  const dict = MESSAGES[lang] ?? MESSAGES.uk;
  const template = dict[key] ?? MESSAGES.uk[key] ?? key;
  return template.replace(/{(\w+)}/g, (_, name) => (params[name] !== undefined ? params[name] : `{${name}}`));
}
