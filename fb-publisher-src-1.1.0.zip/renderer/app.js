/**
 * app.js — логіка renderer-процесу.
 * Працює лише через window.api (наданий preload.cjs) — прямого
 * доступу до Node.js/Playwright тут немає.
 *
 * Примітка: цей файл підключений як звичайний <script> (не ES Module),
 * оскільки Electron завантажує renderer через file://, де ES Module
 * import з локальних файлів має обмеження. i18n.js підключений окремим
 * <script> і надає глобальну функцію getUiText(lang).
 *
 * Програма керує до MAX_ACCOUNTS акаунтів. Кожен акаунт має власну
 * форму (текст, групи, фото, час старту, затримка), власний стан
 * виконання й власний журнал; усі акаунти можуть працювати одночасно.
 */

const el = (id) => document.getElementById(id);

const accountTabsEl = el('accountTabs');
const btnAddAccount = el('btnAddAccount');
const accountLimitEl = el('accountLimit');
const accountNameEl = el('accountName');
const btnDeleteAccount = el('btnDeleteAccount');
const sessionBadgeEl = el('sessionBadge');
const btnLogin = el('btnLogin');
const btnConfirmLogin = el('btnConfirmLogin');
const groupsListEl = el('groupsList');
const postTextEl = el('postText');
const btnSelectImage = el('btnSelectImage');
const btnClearImage = el('btnClearImage');
const imagePathLabel = el('imagePathLabel');
const startTimeEl = el('startTime');
const btnClearTime = el('btnClearTime');
const delayMinEl = el('delayMin');
const delayMaxEl = el('delayMax');
const btnStart = el('btnStart');
const btnPause = el('btnPause');
const btnStop = el('btnStop');
const btnStartAll = el('btnStartAll');
const btnStopAll = el('btnStopAll');
const statusLineEl = el('statusLine');
const progressFillEl = el('progressFill');
const progressLabelEl = el('progressLabel');
const langSelect = el('langSelect');
const logScopeEl = el('logScope');
const logEl = el('log');
const dailyCounterEl = el('dailyCounter');

const MAX_LOG_LINES = 3000;

let currentLang = 'uk';
let maxAccounts = 10;
let accounts = [];
let activeId = null;
let saveTimer = null;
let stats = { total: 0, perAccount: {} };
let sessions = {};
const runtime = {}; // id -> { status, startAt, done, total, loginOpen }
const logLines = []; // { id, time, msg, error }

function rt(id) {
  if (!runtime[id]) runtime[id] = { status: 'idle', startAt: null, done: 0, total: 0, loginOpen: false };
  return runtime[id];
}

function activeAccount() {
  return accounts.find((a) => a.id === activeId) ?? null;
}

function accountName(id) {
  return accounts.find((a) => a.id === id)?.name ?? id;
}

function isBusy(id) {
  const s = rt(id).status;
  return s === 'running' || s === 'waiting' || s === 'paused';
}

function newAccountId() {
  return `a${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

function newAccountObject() {
  const ui = getUiText(currentLang);
  let n = 1;
  while (accounts.some((a) => a.name === ui.defaultAccountName(n))) n++;
  return {
    id: newAccountId(),
    name: ui.defaultAccountName(n),
    text: '',
    groups: [],
    imagePath: '',
    startTime: '',
    delayMinSec: 3,
    delayMaxSec: 5,
  };
}

// --- Збереження налаштувань (автозбереження) ---

function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    window.api.saveConfig({ language: currentLang, accounts, activeAccountId: activeId });
  }, 400);
}

function getGroupsArray() {
  return groupsListEl.value
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line.length > 0);
}

function numberOr(value, fallback) {
  const n = Number.parseFloat(value);
  return Number.isFinite(n) ? n : fallback;
}

/** Переносить значення з форми в активний акаунт. */
function readFormIntoAccount() {
  const account = activeAccount();
  if (!account) return;
  account.name = accountNameEl.value.trim() || account.name;
  account.groups = getGroupsArray();
  account.text = postTextEl.value;
  account.startTime = startTimeEl.value || '';
  account.delayMinSec = numberOr(delayMinEl.value, 3);
  account.delayMaxSec = numberOr(delayMaxEl.value, 5);
}

// --- Переклад ---

function applyTranslations() {
  const ui = getUiText(currentLang);
  el('accountNameLabel').textContent = ui.accountNameLabel;
  btnAddAccount.textContent = ui.btnAddAccount;
  btnDeleteAccount.textContent = ui.btnDeleteAccount;
  el('postTextLabel').textContent = ui.postTextLabel;
  postTextEl.placeholder = ui.postTextPlaceholder;
  el('imageLabel').textContent = ui.imageLabel;
  btnSelectImage.textContent = ui.btnSelectImage;
  btnClearImage.textContent = ui.btnClearImage;
  el('groupsLabel').textContent = ui.groupsLabel;
  groupsListEl.placeholder = ui.groupsPlaceholder;
  el('startTimeLabel').textContent = ui.startTimeLabel;
  btnClearTime.textContent = ui.btnClearTime;
  el('startTimeHint').textContent = ui.startTimeHint;
  el('delayLabel').textContent = ui.delayLabel;
  el('delayFromLabel').textContent = ui.delayFrom;
  el('delayToLabel').textContent = ui.delayTo;
  el('delayUnit').textContent = ui.delayUnit;
  btnLogin.textContent = ui.btnLogin;
  btnConfirmLogin.textContent = ui.btnConfirmLogin;
  btnStart.textContent = ui.btnStart;
  btnStartAll.textContent = ui.btnStartAll;
  btnStopAll.textContent = ui.btnStopAll;
  btnStop.textContent = ui.btnStop;
  el('logLabel').textContent = ui.logLabel;
  logScopeEl.options[0].textContent = ui.logScopeCurrent;
  logScopeEl.options[1].textContent = ui.logScopeAll;
  dailyCounterEl.textContent = ui.dailyCounter(stats.total);
  updateImageLabel();
  renderAll();
}

langSelect.addEventListener('change', () => {
  currentLang = langSelect.value;
  applyTranslations();
  scheduleSave();
});

// --- Відображення ---

function statusText(id) {
  const ui = getUiText(currentLang);
  const state = rt(id);
  if (state.status === 'waiting') {
    const d = new Date(state.startAt ?? Date.now());
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    return ui.statusWaiting(`${hh}:${mm}`);
  }
  if (state.status === 'paused') return ui.statusPaused;
  if (state.status === 'running') return ui.statusRunning;
  return ui.statusIdle;
}

function renderTabs() {
  accountTabsEl.textContent = '';
  for (const account of accounts) {
    const tab = document.createElement('button');
    tab.className = 'account-tab' + (account.id === activeId ? ' account-tab-active' : '');
    tab.dataset.id = account.id;
    tab.title = statusText(account.id);

    const dot = document.createElement('span');
    dot.className = `status-dot status-${rt(account.id).status}`;
    const name = document.createElement('span');
    name.className = 'account-tab-name';
    name.textContent = account.name;
    tab.append(dot, name);

    tab.addEventListener('click', () => selectAccount(account.id));
    accountTabsEl.appendChild(tab);
  }
  const ui = getUiText(currentLang);
  accountLimitEl.textContent = ui.accountLimit(accounts.length, maxAccounts);
  btnAddAccount.disabled = accounts.length >= maxAccounts;
  btnAddAccount.title = accounts.length >= maxAccounts ? ui.limitReached(maxAccounts) : '';
}

function updateImageLabel() {
  const ui = getUiText(currentLang);
  const account = activeAccount();
  const imagePath = account?.imagePath ?? '';
  imagePathLabel.textContent = imagePath || ui.imageNotSelected;
  btnClearImage.hidden = !imagePath;
}

function updateProgressView() {
  const state = rt(activeId);
  const percent = state.total > 0 ? Math.round((state.done / state.total) * 100) : 0;
  progressFillEl.style.width = `${percent}%`;
  progressLabelEl.textContent = `${state.done} / ${state.total}`;
}

function updateControls() {
  const ui = getUiText(currentLang);
  const account = activeAccount();
  if (!account) return;
  const state = rt(account.id);
  const busy = isBusy(account.id);

  btnStart.disabled = busy;
  btnStop.disabled = !busy;
  btnPause.disabled = !(state.status === 'running' || state.status === 'paused');
  btnPause.textContent = state.status === 'paused' ? ui.btnResume : ui.btnPause;
  btnLogin.disabled = busy;
  btnConfirmLogin.hidden = !state.loginOpen;
  btnLogin.hidden = state.loginOpen;
  btnDeleteAccount.disabled = accounts.length <= 1;

  const hasSession = Boolean(sessions[account.id]);
  sessionBadgeEl.textContent = hasSession ? ui.sessionSaved : ui.sessionMissing;
  sessionBadgeEl.className = `badge ${hasSession ? 'badge-ok' : 'badge-off'}`;

  const count = stats.perAccount[account.id] ?? 0;
  statusLineEl.textContent = `${statusText(account.id)} · ${ui.accountToday(count)}`;

  const anyIdle = accounts.some((a) => !isBusy(a.id));
  const anyBusy = accounts.some((a) => isBusy(a.id));
  btnStartAll.disabled = !anyIdle;
  btnStopAll.disabled = !anyBusy;

  dailyCounterEl.textContent = ui.dailyCounter(stats.total);
}

function loadFormFromAccount() {
  const account = activeAccount();
  if (!account) return;
  accountNameEl.value = account.name;
  groupsListEl.value = (account.groups ?? []).join('\n');
  postTextEl.value = account.text ?? '';
  startTimeEl.value = account.startTime ?? '';
  delayMinEl.value = account.delayMinSec ?? 3;
  delayMaxEl.value = account.delayMaxSec ?? 5;
  updateImageLabel();
}

function renderAll() {
  renderTabs();
  updateControls();
  updateProgressView();
  renderLog();
}

function selectAccount(id) {
  if (id === activeId) return;
  readFormIntoAccount();
  activeId = id;
  loadFormFromAccount();
  renderAll();
  scheduleSave();
}

// --- Журнал ---

function formatLogLine(entry, withName) {
  const time = entry.time.toLocaleTimeString(currentLang === 'en' ? 'en-US' : 'uk-UA');
  return withName ? `[${time}] [${accountName(entry.id)}] ${entry.msg}` : `[${time}] ${entry.msg}`;
}

function lineVisible(entry) {
  return logScopeEl.value === 'all' || entry.id === activeId;
}

function appendLogDom(entry) {
  const line = document.createElement('div');
  line.className = entry.error ? 'log-line log-error' : 'log-line';
  line.textContent = formatLogLine(entry, logScopeEl.value === 'all');
  logEl.appendChild(line);
  while (logEl.childElementCount > MAX_LOG_LINES) logEl.firstElementChild.remove();
  logEl.scrollTop = logEl.scrollHeight;
}

function renderLog() {
  logEl.textContent = '';
  for (const entry of logLines) {
    if (lineVisible(entry)) appendLogDom(entry);
  }
}

function appendLog(id, msg, isError = false) {
  const entry = { id, time: new Date(), msg, error: isError };
  logLines.push(entry);
  if (logLines.length > MAX_LOG_LINES) logLines.shift();
  if (lineVisible(entry)) appendLogDom(entry);
}

logScopeEl.addEventListener('change', renderLog);

// --- Редагування полів ---

for (const input of [accountNameEl, groupsListEl, postTextEl, startTimeEl, delayMinEl, delayMaxEl]) {
  input.addEventListener('input', () => {
    readFormIntoAccount();
    if (input === accountNameEl) renderTabs();
    scheduleSave();
  });
}

btnClearTime.addEventListener('click', () => {
  startTimeEl.value = '';
  readFormIntoAccount();
  scheduleSave();
});

btnSelectImage.addEventListener('click', async () => {
  const { path } = await window.api.selectImage();
  const account = activeAccount();
  if (path && account) {
    account.imagePath = path;
    updateImageLabel();
    scheduleSave();
  }
});

btnClearImage.addEventListener('click', () => {
  const account = activeAccount();
  if (!account) return;
  account.imagePath = '';
  updateImageLabel();
  scheduleSave();
});

// --- Додавання / видалення акаунтів ---

btnAddAccount.addEventListener('click', () => {
  if (accounts.length >= maxAccounts) return;
  readFormIntoAccount();
  const account = newAccountObject();
  accounts.push(account);
  activeId = account.id;
  loadFormFromAccount();
  renderAll();
  scheduleSave();
});

btnDeleteAccount.addEventListener('click', async () => {
  const ui = getUiText(currentLang);
  const account = activeAccount();
  if (!account || accounts.length <= 1) return;
  if (isBusy(account.id)) {
    appendLog(account.id, ui.cannotDeleteRunning, true);
    return;
  }
  if (!window.confirm(ui.confirmDeleteAccount(account.name))) return;

  const result = await window.api.deleteAccount(account.id);
  if (!result.ok) {
    appendLog(account.id, ui.cannotDeleteRunning, true);
    return;
  }
  const index = accounts.findIndex((a) => a.id === account.id);
  accounts.splice(index, 1);
  delete runtime[account.id];
  delete sessions[account.id];
  activeId = accounts[Math.min(index, accounts.length - 1)].id;
  loadFormFromAccount();
  renderAll();
  scheduleSave();
});

// --- Логін (окремо для кожного акаунта) ---

btnLogin.addEventListener('click', async () => {
  const account = activeAccount();
  if (!account) return;
  const id = account.id;
  const state = rt(id);
  state.loginOpen = true;
  updateControls();
  appendLog(id, getUiText(currentLang).openingBrowserLog);
  try {
    await window.api.startLogin(id);
  } catch (err) {
    state.loginOpen = false;
    appendLog(id, err.message, true);
    updateControls();
  }
});

btnConfirmLogin.addEventListener('click', async () => {
  const account = activeAccount();
  if (!account) return;
  const id = account.id;
  btnConfirmLogin.disabled = true;
  try {
    await window.api.confirmLogin(id);
  } catch (err) {
    appendLog(id, err.message, true);
  }
  rt(id).loginOpen = false;
  btnConfirmLogin.disabled = false;
  sessions = await window.api.loadSessions();
  updateControls();
});

// --- Публікація ---

/**
 * Перевіряє налаштування акаунта й запускає публікацію.
 * @returns {Promise<boolean>} true, якщо запуск прийнято
 */
async function startAccount(id) {
  const ui = getUiText(currentLang);
  const account = accounts.find((a) => a.id === id);
  if (!account || isBusy(id)) return false;

  if (id === activeId) readFormIntoAccount();

  const text = (account.text ?? '').trim();
  const groups = account.groups ?? [];
  const imagePath = account.imagePath || null;
  const delayMinSec = Number(account.delayMinSec);
  const delayMaxSec = Number(account.delayMaxSec);

  if (!sessions[id]) {
    appendLog(id, ui.errNoSession, true);
    return false;
  }
  if (!text && !imagePath) {
    appendLog(id, ui.errNoContent, true);
    return false;
  }
  if (groups.length === 0) {
    appendLog(id, ui.errNoGroups, true);
    return false;
  }
  if (!Number.isFinite(delayMinSec) || !Number.isFinite(delayMaxSec) || delayMinSec < 0 || delayMaxSec < delayMinSec) {
    appendLog(id, ui.errBadDelay, true);
    return false;
  }
  if (account.startTime && !/^\d{1,2}:\d{2}$/.test(account.startTime)) {
    appendLog(id, ui.errBadTime, true);
    return false;
  }

  const state = rt(id);
  state.done = 0;
  state.total = groups.length;
  state.status = account.startTime ? 'waiting' : 'running';
  if (id === activeId) updateProgressView();
  renderTabs();
  updateControls();

  appendLog(id, account.startTime ? ui.scheduledLog(account.startTime, groups.length) : ui.startingLog(groups.length));

  const result = await window.api.startPublish({
    id,
    text,
    groups,
    imagePath,
    startTime: account.startTime || '',
    delayMinSec,
    delayMaxSec,
  });
  if (!result.ok) {
    state.status = 'idle';
    renderTabs();
    updateControls();
    return false;
  }
  return true;
}

btnStart.addEventListener('click', () => {
  if (activeId) startAccount(activeId);
});

btnPause.addEventListener('click', async () => {
  const id = activeId;
  if (!id) return;
  if (rt(id).status === 'paused') {
    await window.api.resumePublish(id);
  } else {
    await window.api.pausePublish(id);
  }
});

btnStop.addEventListener('click', async () => {
  if (!activeId) return;
  btnStop.disabled = true;
  await window.api.stopPublish(activeId);
});

btnStartAll.addEventListener('click', async () => {
  const ui = getUiText(currentLang);
  let started = 0;
  for (const account of [...accounts]) {
    if (isBusy(account.id)) continue;
    if (await startAccount(account.id)) started++;
  }
  if (started === 0) appendLog(activeId, ui.noAccountsToStart, true);
});

btnStopAll.addEventListener('click', async () => {
  for (const account of accounts) {
    if (isBusy(account.id)) await window.api.stopPublish(account.id);
  }
});

// --- Події з main process ---

window.api.onLog((id, msg) => appendLog(id, msg));

window.api.onProgress((id, done, total) => {
  const state = rt(id);
  state.done = done;
  state.total = total;
  if (id === activeId) updateProgressView();
});

window.api.onStatus((id, status, extra) => {
  const state = rt(id);
  state.status = status;
  state.startAt = extra?.startAt ?? state.startAt;
  renderTabs();
  updateControls();
});

window.api.onPublishFinished((id) => {
  const state = rt(id);
  state.status = 'idle';
  state.startAt = null;
  renderTabs();
  updateControls();
});

window.api.onStatsUpdate((next) => {
  stats = next;
  updateControls();
});

// --- Ініціалізація ---

async function init() {
  const [config, limits, loadedStats, loadedSessions] = await Promise.all([
    window.api.loadConfig(),
    window.api.getLimits(),
    window.api.loadStats(),
    window.api.loadSessions(),
  ]);
  maxAccounts = limits.maxAccounts;
  stats = loadedStats;
  sessions = loadedSessions;
  currentLang = config.language ?? 'uk';
  langSelect.value = currentLang;

  accounts = (Array.isArray(config.accounts) ? config.accounts : []).map((account) => ({
    text: '',
    groups: [],
    imagePath: '',
    startTime: '',
    delayMinSec: 3,
    delayMaxSec: 5,
    ...account,
  }));
  if (accounts.length === 0) accounts.push(newAccountObject());
  activeId = accounts.some((a) => a.id === config.activeAccountId) ? config.activeAccountId : accounts[0].id;

  loadFormFromAccount();
  applyTranslations();
}

init();
