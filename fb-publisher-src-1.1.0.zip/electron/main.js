/**
 * main.js — головний процес Electron.
 * Відкриває вікно застосунку та з'єднує GUI (renderer) з логікою
 * Playwright (src/login.js, src/publisher.js) через IPC-обробники.
 * Renderer не має прямого доступу до Node.js/Playwright — лише через
 * канали, описані в electron/preload.cjs.
 *
 * Підтримує до MAX_ACCOUNTS акаунтів Facebook. Кожен акаунт має власну
 * збережену сесію, власний браузер і власний стан (старт/пауза/зупинка),
 * тому всі акаунти можуть публікувати одночасно.
 */
import { app, BrowserWindow, ipcMain, dialog, shell, clipboard, nativeImage } from 'electron';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { access, copyFile, mkdir, rm } from 'node:fs/promises';
import { startLogin } from '../src/login.js';
import { publishToGroups } from '../src/publisher.js';
import { loadConfig, saveConfig, createAccount, MAX_ACCOUNTS } from '../src/storage.js';
import { createFileLogger } from '../src/logger.js';
import { isChromeInstalled, CHROME_DOWNLOAD_URL } from '../src/chromeCheck.js';
import { loadDailyCount, incrementDailyCount } from '../src/stats.js';
import { t } from '../src/i18n.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// У встановленій програмі Program Files зазвичай доступний лише для читання,
// тому налаштування/cookies/логи зберігаємо в userData (записувана папка
// Windows: %APPDATA%\FB Group Publisher). У режимі розробки — просто ../data.
const DATA_DIR = app.isPackaged
  ? path.join(app.getPath('userData'), 'data')
  : path.join(__dirname, '..', 'data');
const CONFIG_PATH = path.join(DATA_DIR, 'config.json');
const ACCOUNTS_DIR = path.join(DATA_DIR, 'accounts');
const LEGACY_COOKIES_PATH = path.join(DATA_DIR, 'cookies.json');
const LEGACY_STATS_PATH = path.join(DATA_DIR, 'stats.json');
const LOGS_DIR = path.join(DATA_DIR, 'logs');
const logToFile = createFileLogger(LOGS_DIR);

const ID_PATTERN = /^[A-Za-z0-9_-]{1,40}$/;

/** Стан виконання кожного акаунта (в межах одного запуску застосунку). */
const runtimes = new Map(); // id -> { running, stop, pause, loginSession }
let mainWindow = null;

function getRuntime(id) {
  let rt = runtimes.get(id);
  if (!rt) {
    rt = { running: false, stop: false, pause: false, loginSession: null };
    runtimes.set(id, rt);
  }
  return rt;
}

function assertValidId(id) {
  if (typeof id !== 'string' || !ID_PATTERN.test(id)) {
    throw new Error('Invalid account id');
  }
  return id;
}

function cookiesPathFor(id) {
  return path.join(ACCOUNTS_DIR, id, 'cookies.json');
}

function statsPathFor(id) {
  return path.join(ACCOUNTS_DIR, id, 'stats.json');
}

async function fileExists(file) {
  try {
    await access(file);
    return true;
  } catch {
    return false;
  }
}

/**
 * Читає поточну мову інтерфейсу з налаштувань (за замовчуванням 'uk').
 * Читається заново перед кожною дією, щоб перемикання мови в GUI
 * одразу відображалось у нових повідомленнях журналу.
 */
async function getCurrentLang() {
  const config = await loadConfig(CONFIG_PATH);
  return config.language ?? 'uk';
}

/**
 * Міграція зі старих версій (1.0.x), де був один акаунт: переносить текст,
 * групи, зображення, збережену сесію та лічильник у «Акаунт 1».
 */
async function migrateLegacyData() {
  const config = await loadConfig(CONFIG_PATH);
  if (Array.isArray(config.accounts) && config.accounts.length > 0) return;

  const account = createAccount('main', config.language === 'en' ? 'Account 1' : 'Акаунт 1');
  account.text = config.text ?? '';
  account.groups = Array.isArray(config.groups) ? config.groups : [];
  account.imagePath = config.imagePath ?? '';

  if (await fileExists(LEGACY_COOKIES_PATH)) {
    await mkdir(path.dirname(cookiesPathFor(account.id)), { recursive: true });
    await copyFile(LEGACY_COOKIES_PATH, cookiesPathFor(account.id));
  }
  if (await fileExists(LEGACY_STATS_PATH)) {
    await mkdir(path.dirname(statsPathFor(account.id)), { recursive: true });
    await copyFile(LEGACY_STATS_PATH, statsPathFor(account.id));
  }

  await saveConfig(CONFIG_PATH, { accounts: [account], activeAccountId: account.id });
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1180,
    height: 800,
    resizable: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  win.setTitle('FB Group Publisher');
  return win;
}

app.whenReady().then(async () => {
  await migrateLegacyData().catch((err) => logToFile(`Migration failed: ${err.message}`));
  mainWindow = createWindow();

  const chromeFound = await isChromeInstalled();
  if (!chromeFound) {
    const lang = await getCurrentLang();
    const choice = await dialog.showMessageBox(mainWindow, {
      type: 'warning',
      title: t(lang, 'chrome.title'),
      message: t(lang, 'chrome.message'),
      detail: t(lang, 'chrome.detail'),
      buttons: [t(lang, 'chrome.btnDownload'), t(lang, 'chrome.btnClose')],
      defaultId: 0,
      cancelId: 1,
    });
    if (choice.response === 0) {
      shell.openExternal(CHROME_DOWNLOAD_URL);
    }
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      mainWindow = createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

function broadcast(channel, ...args) {
  for (const win of BrowserWindow.getAllWindows()) win.webContents.send(channel, ...args);
}

function sendLog(id, msg) {
  broadcast('log', id, msg);
  logToFile(`[${id}] ${msg}`);
}

/** Лічильники за поточну добу: по кожному акаунту та загальний. */
async function collectStats() {
  const config = await loadConfig(CONFIG_PATH);
  const perAccount = {};
  let total = 0;
  for (const account of config.accounts ?? []) {
    if (!ID_PATTERN.test(account.id)) continue;
    const count = await loadDailyCount(statsPathFor(account.id));
    perAccount[account.id] = count;
    total += count;
  }
  return { total, perAccount };
}

async function sendStats() {
  broadcast('stats:update', await collectStats());
}

// Раз на хвилину перевіряємо, чи не настала нова доба (00:00) — якщо так,
// loadDailyCount поверне 0, і лічильник у GUI сам скинеться навіть якщо
// користувач нічого не публікував рівно опівночі.
setInterval(() => {
  sendStats().catch(() => {});
}, 60000);

async function prepareImageClipboard(imagePath) {
  const image = nativeImage.createFromPath(imagePath);
  if (image.isEmpty()) {
    throw new Error(`Nie udało się odczytać obrazu: ${imagePath}`);
  }
  clipboard.writeImage(image);
}

// Системний буфер обміну один на всі акаунти — доступ до нього послідовний.
let clipboardChain = Promise.resolve();
function withClipboardLock(fn) {
  const run = clipboardChain.then(fn, fn);
  clipboardChain = run.then(() => {}, () => {});
  return run;
}

/**
 * Перетворює "HH:MM" на timestamp сьогоднішнього дня.
 * @returns {{ startAt: number|null, passedTime: string|null }}
 *  startAt — момент старту в майбутньому; passedTime — "HH:MM", якщо
 *  заданий час уже минув (тоді стартуємо одразу).
 */
function resolveStartTime(startTime) {
  const match = /^(\d{1,2}):(\d{2})$/.exec(String(startTime ?? '').trim());
  if (!match) return { startAt: null, passedTime: null };
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  if (hours > 23 || minutes > 59) return { startAt: null, passedTime: null };

  const target = new Date();
  target.setHours(hours, minutes, 0, 0);
  const label = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
  if (target.getTime() <= Date.now()) return { startAt: null, passedTime: label };
  return { startAt: target.getTime(), passedTime: null };
}

// --- Налаштування ---

ipcMain.handle('config:load', async () => {
  return loadConfig(CONFIG_PATH);
});

ipcMain.handle('config:save', async (_event, config) => {
  await saveConfig(CONFIG_PATH, config);
  return { ok: true };
});

ipcMain.handle('meta:limits', async () => ({ maxAccounts: MAX_ACCOUNTS }));

// --- Статистика ---

ipcMain.handle('stats:load', async () => collectStats());

// --- Сесії акаунтів ---

ipcMain.handle('accounts:sessions', async () => {
  const config = await loadConfig(CONFIG_PATH);
  const sessions = {};
  for (const account of config.accounts ?? []) {
    if (!ID_PATTERN.test(account.id)) continue;
    sessions[account.id] = await fileExists(cookiesPathFor(account.id));
  }
  return sessions;
});

ipcMain.handle('account:delete', async (_event, id) => {
  assertValidId(id);
  const rt = getRuntime(id);
  if (rt.running) return { ok: false, error: 'running' };
  if (rt.loginSession) {
    await rt.loginSession.cancel().catch(() => {});
    rt.loginSession = null;
  }
  await rm(path.join(ACCOUNTS_DIR, id), { recursive: true, force: true });
  runtimes.delete(id);
  await sendStats();
  return { ok: true };
});

// --- Вибір зображення ---

ipcMain.handle('image:select', async (event) => {
  const callerWindow = BrowserWindow.fromWebContents(event.sender);
  const result = await dialog.showOpenDialog(callerWindow, {
    title: 'Оберіть зображення для публікації',
    properties: ['openFile'],
    filters: [{ name: 'Зображення', extensions: ['jpg', 'jpeg', 'png', 'gif', 'webp'] }],
  });
  if (result.canceled || result.filePaths.length === 0) return { path: null };
  return { path: result.filePaths[0] };
});

// --- Логін ---

ipcMain.handle('login:start', async (_event, id) => {
  assertValidId(id);
  const rt = getRuntime(id);
  if (rt.loginSession) {
    await rt.loginSession.cancel().catch(() => {});
    rt.loginSession = null;
  }
  const lang = await getCurrentLang();
  rt.loginSession = await startLogin(cookiesPathFor(id), (msg) => sendLog(id, msg), lang);
  return { ok: true };
});

ipcMain.handle('login:confirm', async (_event, id) => {
  assertValidId(id);
  const rt = getRuntime(id);
  if (!rt.loginSession) return { ok: false, error: 'Немає активної сесії логіну.' };
  await rt.loginSession.confirmLogin();
  rt.loginSession = null;
  return { ok: true };
});

ipcMain.handle('login:cancel', async (_event, id) => {
  assertValidId(id);
  const rt = getRuntime(id);
  if (!rt.loginSession) return { ok: false };
  await rt.loginSession.cancel();
  rt.loginSession = null;
  return { ok: true };
});

// --- Публікація (кожен акаунт — незалежно й одночасно) ---

ipcMain.handle('publish:start', async (_event, payload) => {
  const { id, text, groups, imagePath, startTime, delayMinSec, delayMaxSec } = payload;
  assertValidId(id);
  const lang = await getCurrentLang();
  const rt = getRuntime(id);

  if (rt.running) {
    sendLog(id, t(lang, 'publish.alreadyRunning'));
    return { ok: false, error: 'running' };
  }

  const minSec = Number(delayMinSec);
  const maxSec = Number(delayMaxSec);
  if (!Number.isFinite(minSec) || !Number.isFinite(maxSec) || minSec < 0 || maxSec < minSec) {
    sendLog(id, t(lang, 'publish.badDelay'));
    return { ok: false, error: 'delay' };
  }

  const { startAt, passedTime } = resolveStartTime(startTime);
  if (passedTime) sendLog(id, t(lang, 'publish.startTimePassed', { time: passedTime }));

  rt.running = true;
  rt.stop = false;
  rt.pause = false;
  broadcast('account:status', id, startAt ? 'waiting' : 'running', { startAt });

  // Запускаємо публікацію у фоні, щоб не блокувати IPC-відповідь
  publishToGroups({
    text,
    groups,
    imagePath: imagePath || null,
    lang,
    cookiesPath: cookiesPathFor(id),
    startAt,
    delayMinSec: minSec,
    delayMaxSec: maxSec,
    onLog: (msg) => sendLog(id, msg),
    onProgress: (done, total) => broadcast('progress', id, done, total),
    onStatus: (state, extra) => broadcast('account:status', id, state, extra ?? {}),
    shouldStop: () => rt.stop,
    shouldPause: () => rt.pause,
    prepareImageClipboard,
    withClipboardLock,
    onSuccess: async () => {
      const count = await incrementDailyCount(statsPathFor(id));
      sendLog(id, `✔ +1 (${count})`);
      await sendStats();
    },
  })
    .catch((err) => sendLog(id, t(lang, 'publish.criticalError', { message: err.message })))
    .finally(() => {
      rt.running = false;
      rt.pause = false;
      rt.stop = false;
      broadcast('publish:finished', id);
      broadcast('account:status', id, 'idle', {});
    });

  return { ok: true };
});

ipcMain.handle('publish:stop', async (_event, id) => {
  assertValidId(id);
  const rt = getRuntime(id);
  rt.stop = true;
  const lang = await getCurrentLang();
  sendLog(id, t(lang, 'publish.stopRequested'));
  return { ok: true };
});

ipcMain.handle('publish:pause', async (_event, id) => {
  assertValidId(id);
  getRuntime(id).pause = true;
  const lang = await getCurrentLang();
  sendLog(id, t(lang, 'publish.paused'));
  broadcast('account:status', id, 'paused', {});
  return { ok: true };
});

ipcMain.handle('publish:resume', async (_event, id) => {
  assertValidId(id);
  getRuntime(id).pause = false;
  const lang = await getCurrentLang();
  sendLog(id, t(lang, 'publish.resumed'));
  broadcast('account:status', id, 'running', {});
  return { ok: true };
});
